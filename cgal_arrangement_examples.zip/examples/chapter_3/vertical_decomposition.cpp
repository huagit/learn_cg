// File: vertical_decomposition.cpp

#include <list>

#include "arr_exact_construction_segments.h"
#include "read_objects.h"
#include "arr_print.h"
#include "vertical_decomposition.h"
#include "bbox.h"

int main(int argc, char* argv[])
{
  // Get the name of the input file from the command line, or use the default
  // segments.dat file if no command-line parameters are given.
  const char* filename = (argc > 1) ? argv[1] : "segments.dat";
  std::list<Segment>  segments;
  read_objects<Segment>(filename, std::back_inserter(segments));

  // Add four segments of an iso-rectangle that bounds all other segments.
  CGAL::Bbox_2 rect = bbox(segments.begin(), segments.end());
  const Number_type x_min = static_cast<int>(rect.xmin() + 0.5) - 1;
  const Number_type y_min = static_cast<int>(rect.ymin() + 0.5) - 1;
  const Number_type x_max = static_cast<int>(rect.xmax() + 0.5) + 1;
  const Number_type y_max = static_cast<int>(rect.ymax() + 0.5) + 1;
  
  segments.push_back(Segment(Point(x_min, y_min), Point(x_max, y_min)));
  segments.push_back(Segment(Point(x_max, y_min), Point(x_max, y_max)));
  segments.push_back(Segment(Point(x_max, y_max), Point(x_min, y_max)));
  segments.push_back(Segment(Point(x_min, y_max), Point(x_min, y_min)));

  Traits traits;
  Arrangement arr(&traits);
  insert(arr, segments.begin(), segments.end());
  print_arrangement_size(arr);

  // Add vertical edges that induce the vertical decomposition.
  Kernel* kernel = &traits;
  vertical_decomposition(arr, *kernel);
  print_arrangement_size(arr);
  return 0;
}
