// File: ex_batched_point_location.cpp

#include <list>

#include <CGAL/basic.h>
#include <CGAL/Arr_batched_point_location.h>

#include "arr_inexact_construction_segments.h"
#include "point_location_utils.h"

int main()
{
  // Construct the arrangement.
  Arrangement    arr;
  construct_segments_arr(arr);

  // Perform a batched point-location query.
  std::list<Point>       points;
  points.push_back(Point(1, 4));  points.push_back(Point(4, 3));
  points.push_back(Point(6, 3));  points.push_back(Point(3, 2));
  points.push_back(Point(5, 2));  points.push_back(Point(1, 0));
  std::list<std::pair<Point, CGAL::Object> >  results;
  locate(arr, points.begin(), points.end(), std::back_inserter(results));

  // Print the results.
  std::list<std::pair<Point, CGAL::Object> >::const_iterator  res_iter;
  for (res_iter = results.begin(); res_iter != results.end(); ++res_iter)
    print_point_location<Arrangement>(res_iter->first, res_iter->second);
  return 0;
}
