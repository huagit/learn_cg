#ifndef BBOX_H
#define BBOX_H

#include <CGAL/basic.h>

template <typename Input_iterator>
CGAL::Bbox_2 bbox(Input_iterator begin, Input_iterator end)
{
  CGAL_assertion(begin != end);
  CGAL::Bbox_2 rect = (*begin++).bbox();
  while (begin != end) rect = rect + (*begin++).bbox();
  return rect;
}

#endif
