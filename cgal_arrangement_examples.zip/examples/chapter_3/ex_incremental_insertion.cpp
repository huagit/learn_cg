// File: ex_incremental_insertion.cpp

#include <CGAL/basic.h>
#include <CGAL/Arr_naive_point_location.h>

#include "arr_exact_construction_segments.h"
#include "arr_print.h"

typedef CGAL::Arr_naive_point_location<Arrangement>   Naive_pl;

int main()
{
  // Construct the arrangement of five line segments.
  Arrangement  arr;
  Naive_pl     pl(arr);
  insert_non_intersecting_curve(arr, Segment(Point(1, 0), Point(2, 4)), pl);
  insert_non_intersecting_curve(arr, Segment(Point(5, 0), Point(5, 5)));
  insert(arr, Segment(Point(1, 0), Point(5, 3)), pl);
  insert(arr, Segment(Point(0, 2), Point(6, 0)));
  insert(arr, Segment(Point(3, 0), Point(5, 5)), pl);
  print_arrangement_size(arr);

  // Perform a point-location query on the resulting arrangement and print
  // the boundary of the resulting face that contains the query point.
  Point          q(4, 1);
  CGAL::Object   obj = pl.locate(q);
  Arrangement::Face_const_handle  f;
  bool           success = CGAL::assign(f, obj);
  CGAL_assertion(success);
  std::cout << "The query point (" << q << ") is located in: ";
  print_face<Arrangement>(f);
  return 0;
}

