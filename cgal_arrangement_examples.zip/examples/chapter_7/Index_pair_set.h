#ifndef INDEX_PAIR_SET_H
#define INDEX_PAIR_SET_H

#include <utility>
#include <set>

typedef std::pair<unsigned int, unsigned int>               Index_pair;
typedef std::set<Index_pair>                                Index_pair_set;

#endif
