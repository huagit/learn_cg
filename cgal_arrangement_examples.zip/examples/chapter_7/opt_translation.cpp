// File: opt_translation.cpp

#include <vector>
#include <iostream>
#include <sstream>
#include <boost/graph/breadth_first_search.hpp>
#include <boost/graph/adjacency_list.hpp>

#include <CGAL/basic.h>
#include <CGAL/Arr_consolidated_curve_data_traits_2.h>
#include <CGAL/Arr_extended_dcel.h>
#include <CGAL/graph_traits_Dual_Arrangement_2.h>
#include <CGAL/Arr_face_index_map.h>

#include "arr_circular.h"
#include "arr_print.h"
#include "read_objects.h"
#include "Index_pair_set.h"
#include "bipartite_matching.h"

typedef std::vector<Rational_point>                        Point_set;
typedef CGAL::Arr_consolidated_curve_data_traits_2<Traits, Index_pair> 
                                                           Data_traits;
typedef Data_traits::Curve_2                               Indexed_circle;
typedef CGAL::Arr_face_extended_dcel<Data_traits, Index_pair_set>  Dcel;
typedef CGAL::Arrangement_2<Data_traits, Dcel>             Ex_arrangement;
typedef CGAL::Dual<Ex_arrangement>                         Dual_arrangement;

// An event visitor class that associates each graph vertex (namely an
// arrangement face) with its set of indices.
struct Index_pair_set_visitor {
public:
  // The visitor is applied (only when a new face is discovered) according
  // to this event tag.
  typedef boost::on_tree_edge                               event_filter;

  // When examining an edge that belongs to the tree, crossing from the
  // current face to an adjacent face, prepare the index-pair set of that face.
  template <typename Edge, typename Graph>
  void operator()(Edge e, const Graph& g) 
  {
    // Use the index-pair set of the current face (e's source) as a base set.
    // Check whether the base set contains the index pair associated with the
    // edge. If so, this index should be removed from the set of the adjacent
    // face; otherwise, it should be inserted there.
    Index_pair_set base_set = source(e, g)->data();
    Data_traits::Data_container& edge_set = e->curve().data();
    Data_traits::Data_iterator it;
    for (it = edge_set.begin(); it != edge_set.end(); ++it) {
      Index_pair_set::iterator pos = base_set.find(*it);
      if (pos != base_set.end()) base_set.erase(pos);
      else                       base_set.insert(*it);
      target(e, g)->set_data(base_set);
    }
  }
};

// The main function.
int main(int argc, char* argv[])
{
  if (argc < 4) {
    std::cerr << "Usage: " << argv[0]
              << " <point-set #1> <point-set #2> <epsilon>" << std::endl;
    return -1;
  }
  
  // Read the two input point-sets.
  Point_set A, B;
  read_objects<Rational_point>(argv[1], std::back_inserter(A));
  read_objects<Rational_point>(argv[2], std::back_inserter(B));

  // Read the rational error-bound (epsilon) for the match, e.g., 1/1000:
  Number_type epsilon;
  std::istringstream iss(argv[3], std::istringstream::in); iss >> epsilon;
 
  // For each point a in A and b in B, construct a circle centered at (b - a)
  // with radius epsilon. This circle defines a disc in the translation plane
  // of all valid translations such that || T(a) - b || < epsilon.
  const unsigned int m = A.size(), n = B.size();
  std::vector<Indexed_circle>  circs(m*n);
  for (unsigned int i = 0; i < m; ++i) {
    for (unsigned int j = 0; j < n; ++j) {
      // Note that we use the constructor for a circle given its radius
      // (instead of the squared radius). The orientation is counterclockwise.
      Rational_point  center(B[j].x() - A[i].x(), B[j].y() - A[i].y());
      Curve           circle(center, epsilon, CGAL::COUNTERCLOCKWISE);
      circs[i*n + j] = Indexed_circle(circle, Index_pair(i, j));
    }
  }
  
  // Construct the arrangement of all circles.
  Ex_arrangement  arr;
  insert(arr, circs.begin(), circs.end());

  // Create a mapping of the arrangement faces to indices.
  CGAL::Arr_face_index_map<Ex_arrangement>  index_map(arr);

  // Perform breadth-first search from the unbounded face. Use the event
  // visitor to associate each arrangement face with its index-pair set.
  Ex_arrangement::Face_handle               uf = arr.unbounded_face();  
  boost::breadth_first_search(Dual_arrangement(arr), uf,
                              boost::vertex_index_map(index_map).
                              visitor(boost::make_bfs_visitor
                                      (Index_pair_set_visitor())));

  // Go over the arrangement faces and find the best one.
  Ex_arrangement::Face_const_iterator  fit;
  unsigned int                         curr_match;
  Ex_arrangement::Face_const_handle    opt_face = uf;
  unsigned int                         best_match = 0;
  for (fit = arr.faces_begin(); fit != arr.faces_end(); ++fit) {
    // Compute the maximal match of indices pair over the current face.
    curr_match = bipartite_matching(m, n, fit->data());
    if (curr_match > best_match) {
      // Update if we have found a better match than the best so far.
      opt_face = fit;
      best_match = curr_match;
    }
  }

  // Recompute and print the best match.
  Index_pair_set                              opt_set;
  Index_pair_set::const_iterator              ips_it;
  bipartite_matching(m, n, opt_face->data(), &opt_set);
  std::cout << "Found " << best_match << " matching point pairs:" << std::endl;
  for (ips_it = opt_set.begin(); ips_it != opt_set.end(); ++ips_it)
    std::cout << "  (" << A[ips_it->first]
              << ") --> (" << B[ips_it->second] << ')' << std::endl;
  return 0;
}
