#ifndef BIPARTITE_MATCHING_H
#define BIPARTITE_MATCHING_H

// Find the largest common point set for a specific set of index pairs by 
// bipartite_matching.

#include <vector>
#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/max_cardinality_matching.hpp>

#include "Index_pair_set.h"

unsigned int bipartite_matching(unsigned int m, unsigned int n,
                                const Index_pair_set& index_pair_set,
                                Index_pair_set* match_set = NULL)
{
  typedef boost::adjacency_list<boost::vecS, boost::vecS, boost::undirectedS>
    Graph;

  // Create a graph with (m + n) vertices. The first m vertices and the last n
  // vertices represent the points of the set A and the set B, respectively.
  Graph  G(m + n);

  // Add the graph edges: create an edge between pairs of 'A' 
  // and 'B' vertices according to the given index-pair set. 
  Index_pair_set::const_iterator  it;
  for (it = index_pair_set.begin(); it != index_pair_set.end(); ++it)
    boost::add_edge(it->first, it->second + m, G);

  // The mate vector holds the result matching.
  std::vector<boost::graph_traits<Graph>::vertex_descriptor> mate(m + n);

  // Perform the maximum cardinality matching algorithm.
  boost::edmonds_maximum_cardinality_matching(G, &mate[0]);
  unsigned int match_size = boost::matching_size(G, &mate[0]);

  if (match_set != NULL) {
    // Obtain the match.
    boost::graph_traits<Graph>::vertex_iterator vi, vi_end;
    for (tie(vi, vi_end) = vertices(G); vi != vi_end; ++vi)
      if ((mate[*vi] != boost::graph_traits<Graph>::null_vertex()) &&
          (*vi < mate[*vi]))
        match_set->insert(Index_pair(*vi, mate[*vi] - m));
  }
  return match_size;
}

#endif
