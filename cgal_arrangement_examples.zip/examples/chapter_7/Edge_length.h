#ifndef EDGE_LENGTH_H
#define EDGE_LENGTH_H

#include <boost/property_map.hpp>
#include <CGAL/basic.h>

template <typename Arrangement> class Edge_length {
public:
  // Boost property-type definitions.
  typedef boost::readable_property_map_tag      category;
  typedef double                                value_type;
  typedef value_type                            reference;
  typedef typename Arrangement::Halfedge_handle key_type;

  double operator()(typename Arrangement::Halfedge_handle e) const
  {
    const double diff_x = CGAL::to_double(e->target()->point().x()) -
      CGAL::to_double(e->source()->point().x());
    const double diff_y = CGAL::to_double(e->target()->point().y()) -
      CGAL::to_double(e->source()->point().y());
    return std::sqrt(diff_x*diff_x + diff_y*diff_y);
  }

  friend double get(const Edge_length& edge_length, key_type key)
  { return edge_length(key); }
};

#endif
