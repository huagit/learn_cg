// File: ex_non_caching_segments.cpp

#include <list>
#include <iostream>
#include <boost/timer.hpp>

#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>
#include <CGAL/Arr_non_caching_segment_basic_traits_2.h>
#include <CGAL/Arrangement_2.h>
#include <CGAL/Timer.h>

#include "arr_print.h"
#include "read_objects.h"

typedef CGAL::Exact_predicates_inexact_constructions_kernel   Kernel;
typedef Kernel::FT                                            Number_type;
typedef CGAL::Arr_non_caching_segment_basic_traits_2<Kernel>  Traits;
typedef Traits::Point_2                                       Point;
typedef Traits::X_monotone_curve_2                            Segment;
typedef CGAL::Arrangement_2<Traits>                           Arrangement;

int main(int argc, char* argv[])
{
  // Get the name of the input file from the command line, or use the default
  // Europe.dat file if no command-line parameters are given.
  const char* filename = (argc > 1) ? argv[1] : "Europe.dat";
  std::list<Segment>  segments;
  read_objects<Segment>(filename, std::back_inserter(segments));
  
  // Construct the arrangement by aggregately inserting all segments.
  Arrangement  arr;
  std::cout << "Performing aggregated insertion of " 
            << segments.size() << " segments." << std::endl;
  boost::timer timer;
  insert_non_intersecting_curves(arr, segments.begin(), segments.end());
  double secs = timer.elapsed();

  print_arrangement_size(arr);
  std::cout << "Construction took " << secs << " seconds." << std::endl;
  return 0;
}
