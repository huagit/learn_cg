// File: ex_polylines.cpp

#include <list>
#include <vector>

#include "arr_polylines.h"
#include "arr_print.h"

int main()
{
  // Construct three polylines and compute their arrangement.
  Point pts1[] =
    {Point(0, 0), Point(2, 4), Point(3, 0), Point(4, 4), Point(6, 0)};

  std::list<Point>    pts2;
  pts2.push_back(Point(1, 3));       pts2.push_back(Point(0, 2));
  pts2.push_back(Point(1, 0));       pts2.push_back(Point(2, 1));
  pts2.push_back(Point(3, 0));       pts2.push_back(Point(4, 1));
  pts2.push_back(Point(5, 0));       pts2.push_back(Point(6, 2));
  pts2.push_back(Point(5, 3));       pts2.push_back(Point(4, 2));

  std::vector<Point>  pts3(4);
  pts3[0] = Point(0, 2);             pts3[1] = Point(1, 2);
  pts3[2] = Point(3, 6);             pts3[3] = Point(5, 2);

  Arrangement         arr;
  insert(arr, Polyline(&pts1[0], &pts1[5]));         // pi1
  insert(arr, Polyline(pts2.begin(), pts2.end()));   // pi2
  insert(arr, Polyline(pts3.begin(), pts3.end()));   // pi3

  print_arrangement(arr);
  return 0;
}
