// File: polygon_orientation.cpp

#include<list>

#include <CGAL/Exact_predicates_exact_constructions_kernel.h>
#include <CGAL/Arr_segment_traits_2.h>

#include "arr_exact_construction_segments.h"
#include "read_objects.h"
#include "polygon_orientation.h"

typedef CGAL::Exact_predicates_exact_constructions_kernel Kernel;
typedef Kernel::FT                                        Number_type;
typedef CGAL::Arr_segment_traits_2<Kernel>                Traits;
typedef Traits::Point_2                                   Point;
typedef Traits::X_monotone_curve_2                        Segment;

int main(int argc, char* argv[])
{
  std::list<Point> points;
  const char* filename = (argc > 1) ? argv[1] : "polygon.dat";
  read_objects<Point>(filename, std::back_inserter(points));
  CGAL_assertion(points.size() >= 3);

  std::list<Segment> segments;
  std::list<Point>::const_iterator it = points.begin();
  const Point& first_point = *it++;
  const Point* prev_point = &first_point;
  while (it != points.end()) {
    const Point& point = *it++;
    segments.push_back(Segment(*prev_point, point));
    prev_point = &point;
  }
  segments.push_back(Segment(*prev_point, first_point));
  CGAL::Orientation orient =
    polygon_orientation(segments.begin(), segments.end(), Traits());
  std::cout << ((orient == CGAL::COUNTERCLOCKWISE) ?
                "Counterclockwise" : "Clockwise") << std::endl;
  return 0;
}
