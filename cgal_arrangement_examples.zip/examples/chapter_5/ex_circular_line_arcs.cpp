// File: ex_circular_line_arcs.cpp

#include <math.h>
#include <iostream>
#include <boost/variant.hpp>
#include <boost/lexical_cast.hpp>

#include <CGAL/Cartesian.h>
#include <CGAL/Gmpq.h>
#include <CGAL/Random.h>
#include <CGAL/Algebraic_kernel_for_circles_2_2.h>
#include <CGAL/Circular_kernel_2.h>
#include <CGAL/Arr_circular_line_arc_traits_2.h>
#include <CGAL/Arrangement_2.h>

#include "arr_print.h"

typedef CGAL::Gmpq                                          Number_type;
typedef CGAL::Cartesian<Number_type>                        Linear_k;
typedef CGAL::Algebraic_kernel_for_circles_2_2<Number_type> Algebraic_k;
typedef CGAL::Circular_kernel_2<Linear_k, Algebraic_k>      Circular_k;
typedef Circular_k::Point_2                                 Point;
typedef Circular_k::Circle_2                                Circle;
typedef Circular_k::Circular_arc_2                          Circular_arc;
typedef Circular_k::Line_arc_2                              Line_arc;
typedef boost::variant<Circular_arc, Line_arc>              Arc;
typedef CGAL::Arr_circular_line_arc_traits_2<Circular_k>    Traits;
typedef CGAL::Arrangement_2<Traits>                         Arrangement;

int main(int argc, char* argv[])
{
  CGAL::Random generator;
  const int seed = (argc > 1) ?
    boost::lexical_cast<int>(argv[1]) : generator.get_int(0, 123456);
  CGAL::Random the_random(seed);
  std::cout << "The random seed: " << seed << std::endl;
  const int random_max = 128, random_min = -128;
  std::vector<Arc_2> arcs;

  for (int i = 0; i < 4; ++i) {
    int x1 = the_random.get_int(random_min, random_max);
    int y1 = the_random.get_int(random_min, random_max);
    int x2, y2;
    do {
      x2 = the_random.get_int(random_min, random_max);
      y2 = the_random.get_int(random_min, random_max);
    } while((x1 == x2) && (y1 == y2));
    Arc cv = Line_arc_2(Point(x1, y1), Point(x2, y2));
    arcs.push_back(cv);
  }

  for (int i = 0; i < 4; ++i) {
    int radius_square = the_random.get_int(1, random_max*random_max);
    int radius = static_cast<int>(sqrt(static_cast<double>(radius_square)));
    int x1 = the_random.get_int(random_min + radius, random_max - radius);
    int y1 = the_random.get_int(random_min + radius, random_max - radius);
    Arc_2 cv = Circle_2(Point_2(x1, y1), radius_square);
    arcs.push_back(cv);
  }

  Arrangement arr;
  insert(arr, arcs.begin(), arcs.end());
  print_arrangement_size(arr);
  return 0;
}
