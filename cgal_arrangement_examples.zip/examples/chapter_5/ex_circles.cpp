// File: ex_circles.cpp

#include "arr_circular.h"

int main()
{
  Arrangement  arr;

  // Create a circle centered at the origin with radius 5 (C1).
  insert(arr, Curve(Circle(Rational_point(0, 0), Number_type(25))));

  // Create a circle centered at (7,7) with radius 5 (C2).
  insert(arr, Curve(Circle(Rational_point(7, 7), Number_type(25))));

  // Create a circle centered at (4,-0.5) with radius 3.5 (= 7/2) (C3).
  Rational_point c3 = Rational_point(4, Number_type(-1) / Number_type(2));
  insert(arr, Curve(Circle(c3, Number_type(49) / Number_type(4))));
  
  // Locate the vertex with maximal degree.
  Arrangement::Vertex_const_iterator  vit = arr.vertices_begin();
  Arrangement::Vertex_const_handle    v_max = vit;
  for (++vit; vit != arr.vertices_end(); ++vit)
    if (vit->degree() > v_max->degree()) v_max = vit;

  std::cout << "The vertex with maximal degree in the arrangement is: "
            << "v_max = (" << v_max->point() << ") "
            << "with degree " << v_max->degree() << "." << std::endl;
  return 0;
}
