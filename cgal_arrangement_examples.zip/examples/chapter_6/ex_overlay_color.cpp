// File: ex_overlay_color.cpp

#include <CGAL/basic.h>
#include <CGAL/Arr_extended_dcel.h>
#include <CGAL/Arr_overlay_2.h>
#include <CGAL/Arr_default_overlay_traits.h>

#include "arr_exact_construction_segments.h"
#include "Overlay_color_traits.h"

typedef unsigned int                                         Color;
typedef CGAL::Arr_extended_dcel<Traits, Color, Color, Color> Dcel;
typedef CGAL::Arrangement_2<Traits, Dcel>                    Ex_arrangement;

int main()
{
  Ex_arrangement::Vertex_iterator    vit; 
  Ex_arrangement::Halfedge_iterator  hit; 
  Ex_arrangement::Face_iterator      fit; 

  const Color vcol1(0x00000080), hcol1(0x000000ff), fcol1(0x00ccccff);
  const Color vcol2(0x00800000), hcol2(0x00ff0000), fcol2(0x00ffcccc);
  
  // Construct the first arrangement and assign colors to its features.
  Ex_arrangement  arr1;
  insert_non_intersecting_curve(arr1, Segment(Point(0, 0), Point(4, 0)));
  insert_non_intersecting_curve(arr1, Segment(Point(0, 2), Point(4, 2)));
  insert_non_intersecting_curve(arr1, Segment(Point(0, 4), Point(4, 4)));
  insert(arr1, Segment(Point(0, 0), Point(0, 4)));
  insert(arr1, Segment(Point(2, 0), Point(2, 4)));
  insert(arr1, Segment(Point(4, 0), Point(4, 4)));
  CGAL_assertion(arr1.number_of_faces() == 5);
  for (vit = arr1.vertices_begin(); vit != arr1.vertices_end(); ++vit)
    vit->set_data(vcol1);
  for (hit = arr1.halfedges_begin(); hit != arr1.halfedges_end(); ++hit)
    hit->set_data(hcol1);
  for (fit = arr1.faces_begin(); fit != arr1.faces_end(); ++fit)
    fit->set_data(fcol1);

  // Construct the second arrangement and assign colors to its features.
  Ex_arrangement  arr2;
  insert_non_intersecting_curve(arr2, Segment(Point(0, 0), Point(6, 0)));
  insert_non_intersecting_curve(arr2, Segment(Point(0, 3), Point(6, 3)));
  insert_non_intersecting_curve(arr2, Segment(Point(0, 6), Point(6, 6)));
  insert(arr2, Segment(Point(0, 0), Point(0, 6)));
  insert(arr2, Segment(Point(3, 0), Point(3, 6)));
  insert(arr2, Segment(Point(6, 0), Point(6, 6)));
  CGAL_assertion(arr2.number_of_faces() == 5);
  for (vit = arr2.vertices_begin(); vit != arr2.vertices_end(); ++vit)
    vit->set_data(vcol2);
  for (hit = arr2.halfedges_begin(); hit != arr2.halfedges_end(); ++hit)
    hit->set_data(hcol2);
  for (fit = arr2.faces_begin(); fit != arr2.faces_end(); ++fit)
    fit->set_data(fcol2);

  // Compute the overlay of the two arrangements, while blending the colors
  // of their features.
  Ex_arrangement  ovl_arr;
  Overlay_color_traits<Ex_arrangement> overlay_traits;
  CGAL::overlay(arr1, arr2, ovl_arr, overlay_traits);

  // Print the overlay-arrangement vertices and their colors.
  for (vit = ovl_arr.vertices_begin(); vit != ovl_arr.vertices_end(); ++vit)
    std::cout << vit->point() << ": 0x" << std::hex << std::setfill('0')
              << std::setw(6) << vit->data() << std::endl;
  return 0;
}
