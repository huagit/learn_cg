// File: ex_dcel_extension.cpp

#include <CGAL/basic.h>
#include <CGAL/Arr_extended_dcel.h>

#include "arr_exact_construction_segments.h"

enum Color {BLUE, RED, WHITE};

typedef CGAL::Arr_extended_dcel<Traits, Color, bool, unsigned int>    Dcel;
typedef CGAL::Arrangement_2<Traits, Dcel>                   Ex_arrangement;

int main()
{
  // Construct the arrangement containing two intersecting triangles.
  Traits traits;
  Ex_arrangement  arr(&traits);
  insert_non_intersecting_curve(arr, Segment(Point(4, 1), Point(7, 6)));
  insert_non_intersecting_curve(arr, Segment(Point(1, 6), Point(7, 6)));
  insert_non_intersecting_curve(arr, Segment(Point(4, 1), Point(1, 6)));
  insert(arr, Segment(Point(1, 3), Point(7, 3)));
  insert(arr, Segment(Point(1, 3), Point(4, 8)));
  insert(arr, Segment(Point(4, 8), Point(7, 3)));
  insert_point(arr, Point(4, 4.5));

  // Go over all arrangement vertices and set their colors according to our
  // coloring convention.
  Ex_arrangement::Vertex_iterator  vit;
  for (vit = arr.vertices_begin(); vit != arr.vertices_end(); ++vit) {
    unsigned int degree = vit->degree();
    vit->set_data((degree == 0) ? BLUE : ((degree <= 2) ? RED : WHITE));
  }

  // Go over all arrangement edges and set their flags.
  // Recall that the value type of the edge iterator is the halfedge type.
  Traits::Equal_2 equal = traits.equal_2_object();
  Ex_arrangement::Edge_iterator  eit;
  for (eit = arr.edges_begin(); eit != arr.edges_end(); ++eit) {
    // Check whether the halfegde has the same direction as its segment.
    bool flag = equal(eit->source()->point(),eit->curve().source());
    eit->set_data(flag);
    eit->twin()->set_data(!flag);
  }

  // Store the size of the outer boundary of every face of the arrangement.
  Ex_arrangement::Face_iterator    fit;
  for (fit = arr.faces_begin(); fit != arr.faces_end(); ++fit) {
    unsigned int boundary_size = 0;
    if (! fit->is_unbounded()) {
      Ex_arrangement::Ccb_halfedge_circulator  curr = fit->outer_ccb();
      boundary_size = std::distance(++curr, fit->outer_ccb())+1;
    }
    fit->set_data(boundary_size);
  }

  // Copy the arrangement and print the vertices along with their colors.
  Ex_arrangement    arr2 = arr;

  std::cout << "The arrangement vertices:" << std::endl;
  for (vit = arr2.vertices_begin(); vit != arr2.vertices_end(); ++vit) {
    std::cout << '(' << vit->point() << ") - ";
    switch (vit->data()) {
      case BLUE  : std::cout << "BLUE."  << std::endl; break;
      case RED   : std::cout << "RED."   << std::endl; break;
      case WHITE : std::cout << "WHITE." << std::endl; break;
    }
  }

  std::cout << "The arrangement outer-boundary sizes:";
  for (fit = arr2.faces_begin(); fit != arr2.faces_end(); ++fit)
    std::cout << " " << fit->data();
  std::cout << std::endl;
  return 0;
}
