#ifndef POLYGON_REPAIRING_H
#define POLYGON_REPAIRING_H

#include <utility>

#include <CGAL/basic.h>
#include <CGAL/Arrangement_with_history_2.h>
#include <CGAL/Arr_extended_dcel.h>

#include "Winding_number.h"

template <typename Traits, typename Input_iterator, typename Container>
void polygon_repairing(Input_iterator begin, Input_iterator end,
                       Container& res, const Traits& traits)
{
  // Each face is extended with a pair of a Boolean flag and an integral
  // field: The former indicates whether the face has been discovered
  // already during the traversal. The latter stores the winding number.
  typedef std::pair<bool, int>                              Data;
  typedef CGAL::Arr_face_extended_dcel<Traits, Data>        Dcel;
  typedef CGAL::Arrangement_with_history_2<Traits, Dcel>    Arrangement;

  Arrangement arr(&traits);
  insert(arr, begin, end);
  Winding_number<Arrangement> winding_number(arr);

  typename Arrangement::Face_iterator fi;
  for (fi = arr.faces_begin(); fi != arr.faces_end(); ++fi) {
    if ((fi->data().second % 2) == 0) continue;

    CGAL_assertion(!fi->is_unbounded());
    typename Container::value_type polygon;
    typename Arrangement::Ccb_halfedge_circulator cco = fi->outer_ccb();
    do polygon.push_back(cco->curve());
    while (++cco != fi->outer_ccb());
    res.push_back(polygon);
  }
}

#endif
