#!/usr/bin/perl -w

use Getopt::Long;

my $help = 0;
my $segments_num = 64;
my $vertical = 0;
my $gap = 1;
my $length = 64;
my $x0 = 0;
my $y0 = 0;
$Getopt::Long::ignorecase = 0;
GetOptions("help" => \$help,
	   "number=i" => \$segments_num,
	   "vertical" => \$vertical,
	   "gap=i" => \$gap,
	   "length=i" => \$length) or die "Bad command line option!";
usage() if $help;

if ($vertical) {
  $x1 = $x0;
  $y1 = $y0 + $length;
} else {
  $x1 += $length;
  $y1 = $y0;
}

print "$segments_num\n";
for ($i = 0; $i < $segments_num; $i++) {
  print "$x0 $y0 $x1 $y1\n";
  if ($vertical) {
    $x0 += $gap;
    $x1 += $gap;
  } else {
    $y0 += $gap;
    $y1 += $gap;
  }
}

exit(0);

sub usage {
  printf "gen_vertical.pl";
  printf "
\t--help\t\t\tprint this help message
\t--vertical \t\tgenerate vertical segments (default false)
\t--gap <units>\t\tset the gap between parallel segments to <units> (default 1)
\t--length <units>\tset the length of the segments to <units> (default 1)
\t--segments <num>\tset number of segments to <num> (default 64)
";
  exit(0);
}
