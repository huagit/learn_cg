// File: mp_tr_polygon.cpp

#include <iostream>

#include <CGAL/basic.h>
#include <CGAL/minkowski_sum_2.h>
#include <CGAL/Arr_vertical_decomposition_2.h>
#include <CGAL/Arr_landmarks_point_location.h>
#include <CGAL/graph_traits_Dual_Arrangement_2.h>
#include <CGAL/Arr_face_index_map.h>
#include <CGAL/Arr_observer.h>

#include <boost/property_map.hpp>
#include <boost/graph/breadth_first_search.hpp>
#include <boost/graph/visitors.hpp>
#include <boost/graph/filtered_graph.hpp>

#include "Less_than_handle.h"
#include "bops_set_linear.h"
#include "read_objects.h"
#include "vertical_decomposition.h"
#include "point_in_vertical_trapezoid.h"

typedef Polygon_set::Arrangement_2                      Arrangement;
typedef Arrangement::X_monotone_curve_2                 Segment;
typedef Arrangement::Vertex_handle                      Vertex_handle;
typedef Arrangement::Vertex_const_handle                Vertex_const_handle;
typedef Arrangement::Halfedge_handle                    Halfedge_handle;
typedef Arrangement::Halfedge_const_handle              Halfedge_const_handle;
typedef Arrangement::Face_handle                        Face_handle;
typedef Arrangement::Face_const_handle                  Face_const_handle;
typedef CGAL::Arr_landmarks_point_location<Arrangement> Landmarks_pl;
typedef std::pair<Point, Point>                         Point_pair;

std::istream& operator>>(std::istream& is, Point_pair& pp)
{ return is >> pp.first >> pp.second; }

// ------------------------------------------------------------------------
// The exception is used inside a boost algorithm when the goal vertex 
// has been found. Throwing an exception is the standard way of boost to
// stop the traversal in the middle (see for example the boost FAQ).
class Found_vertex_exception : public std::exception {};

// ------------------------------------------------------------------------
// This visitor throws the exception when the goal vertex have been found.
template <typename Vertex> class Find_vertex_visitor {
private:
  Vertex m_goal;
public:
  typedef boost::on_finish_vertex            event_filter;

  Find_vertex_visitor(Vertex v) : m_goal(v) {}

  template <class Graph> void operator()(Vertex v, const Graph& g)
  { if (v == m_goal) throw Found_vertex_exception(); }
};

// ------------------------------------------------------------------------
// Functor for determing whether a face is in the free space.
struct Is_face_free {
  bool operator()(Face_handle f) const
  { return !f->is_unbounded() && !f->contained(); }
  bool operator()(Face_const_handle f) const
  { return !f->is_unbounded() && !f->contained(); }
};

// ------------------------------------------------------------------------
// This is because of a boost bug in filtered_graph
// Move this to graph_traits_Dual... ???
namespace boost
{
  template <class Arr>
  struct edge_property_type<CGAL::Dual<Arr> > { typedef void type; };
  template <class Arr>
  struct vertex_property_type<CGAL::Dual<Arr> > { typedef void type; };
}

// ------------------------------------------------------------------------
// Returns the free face that the point is contained in. If the point is 
// is not in the free space, the function returns an empty handle.
Face_const_handle get_free_face(const Landmarks_pl& pl, const Point& p)
{
  // Perform point-location queries and locate the point (configuration).
  CGAL::Object       obj = pl.locate(p);

  // Check whether the point lies on an edge separating two forbidden faces.
  Halfedge_const_handle  hh;
  if (CGAL::assign(hh, obj)) {
    if (! hh->face()->contained() && ! hh->twin()->face()->contained())
      return hh->face();
    return Face_const_handle();
  }
  
  // Check whether the point is contained inside a free bounded face.
  Face_const_handle      fh;
  if (! CGAL::assign(fh, obj) || fh->is_unbounded() || fh->contained())
    return Face_const_handle();
  return fh;
}

// ------------------------------------------------------------------------
// Check if the two given configurations are reachable from one another,
// and if so - plan a path connecting these two configurations.
template <typename Output_iterator>
Output_iterator plan_path(Arrangement& arr, Landmarks_pl& pl, 
                          const Point& ps, const Point& pg,
                          Output_iterator path, Kernel& ker)
{
  typedef CGAL::Dual<Arrangement>                        Dual_arrangement;
  typedef CGAL::Arr_face_index_map<Arrangement>          Face_index_map;
  typedef std::map<Face_handle, Face_handle, Less_than_handle>     Preds_map;
  typedef std::map<Face_handle, Halfedge_handle, Less_than_handle> Edges_map;

  // Get the free-space faces that contain the source and target points
  // (checking that they are contained in the free space).
  Face_const_handle      fh;
  fh = get_free_face(pl, ps);
  if (fh == Face_const_handle()) return path;
  Face_handle fs = arr.non_const_handle(fh);

  fh = get_free_face(pl, pg);
  if (fh == Face_const_handle()) return path;
  Face_handle fg = arr.non_const_handle(fh);

  // The Boost BFS records the predecessor faces and the predecessor edges,
  // and stops when the goal face discovered.
  Face_index_map                   index_map(arr);
  Preds_map                        preds_map;
  Edges_map                        edges_map;
  
  // Define a visitor to stop the search when we reach the goal.
  Find_vertex_visitor<Face_handle> find_vertex_visitor(fg);
  
  // We use a filter graph to traverse only the free faces.
  Dual_arrangement                 dual(arr);
  boost::filtered_graph<Dual_arrangement, boost::keep_all, Is_face_free>
    graph(dual, boost::keep_all());
  
  try {
    preds_map[fs] = Face_handle(); edges_map[fs] = Halfedge_handle();
    boost::breadth_first_search(graph, fs,
                                boost::vertex_index_map(index_map).visitor
                                (make_bfs_visitor(
                                  make_pair(
                                    find_vertex_visitor, 
                                    make_pair(
                                      record_predecessors(
                                        make_assoc_property_map(preds_map),
                                        boost::on_tree_edge()),
                                      record_edge_predecessors(
                                        make_assoc_property_map(edges_map),
                                        boost::on_tree_edge()))))));
    
    // If there is a path then an exception should have been thrown.
    return path;
  }
  catch(Found_vertex_exception e) {}

  // We arrive here only if an exception was thrown and a path exists.

  // Reconstruct the path from the BFS results going backward.
  Kernel::Construct_midpoint_2  midp = ker.construct_midpoint_2_object();
  *path++ = pg;
  
  Face_handle f = fg;
  do {
    *path++ = point_in_vertical_trapezoid(f, arr, ker);
    Halfedge_handle he = edges_map[f];
    if (he != Halfedge_handle())
      // Add the midpoint of the associated vertical segment.
      *path++ = midp(he->source()->point(), he->target()->point());
    f = preds_map[f];
  } while (f != Face_handle());
  *path++ = ps;

  return path;
}

// ------------------------------------------------------------------------
// Observer class for the vertical decomposition. The class copies the 
// information in the split_face event so it will be updated on both faces.
class Vertical_decomposition_polygon_set_observer : 
  public CGAL::Arr_observer<Arrangement>
{
  void after_split_face(Face_handle f1, Face_handle f2, bool)
  { f2->set_contained(f1->contained()); }
};

// ------------------------------------------------------------------------
// The main application:
int main(int argc, char* argv[])
{
  if (argc < 4) {
    std::cout << "Usage: " << argv[0]
              << " <obstacles file> <polygon file> <queries file>" << std::endl;
    return -1;
  }

  // Read the polygonal obstacles from the first input file.
  std::list<Polygon>    obstacles;
  read_objects<Polygon>(argv[1], std::back_inserter(obstacles));

  // Read the polygonal robot from the second input file.
  std::ifstream           frobot(argv[2]);
  if (! frobot.is_open()) {
    std::cerr << "Failed to open " << argv[2] << std::endl;
    return -1;
  }
  Polygon robot;
  frobot >> robot;
  frobot.close();

  // Reflect the robot about the origin by negating each vertex.
  Polygon::Vertex_const_iterator  vit;
  Polygon                         rot_robot;
  for (vit = robot.vertices_begin(); vit != robot.vertices_end(); ++vit)
    rot_robot.push_back(Point(-vit->x(), -vit->y()));
  if (rot_robot.orientation() == CGAL::CLOCKWISE)
    rot_robot.reverse_orientation();

  // Compute the Minkowski sum of each obstacle with the rotated robot.
  std::list<Polygon>::const_iterator  obs_it;
  std::list<Polygon_with_holes>       c_obstacles;
  for (obs_it = obstacles.begin(); obs_it != obstacles.end(); ++obs_it)
    c_obstacles.push_back(CGAL::minkowski_sum_2(*obs_it, rot_robot));

  // Compute forbidden configuraion-space and extract the underlying arrangement.
  // The observer keeps the information updated in the new faces.
  Polygon_set::Traits_2 traits;
  Polygon_set  cforb(traits);
  cforb.join(c_obstacles.begin(), c_obstacles.end());
  Arrangement arr = cforb.arrangement();
  Vertical_decomposition_polygon_set_observer observer;
  observer.attach(arr);
  Kernel* ker = &traits;
  vertical_decomposition(arr, *ker);
  observer.detach();

  // Read the query points, and plan the paths.
  Landmarks_pl  pl(arr);
  std::list<Point_pair> queries;
  read_objects<Point_pair>(argv[3], std::back_inserter(queries));
  std::list<Point_pair>::const_iterator it;
  for (it = queries.begin(); it != queries.end(); ++it) {
    std::list<Point> path;
    plan_path(arr, pl, it->first, it->second, std::back_inserter(path), *ker);

    // Print the results.
    std::cout << "Query: (" << it->first << ") and (" << it->second
              << ") are" << (path.empty() ? " NOT " : " ") << "reachable."
              << std::endl;
    if (path.empty()) continue;
    std::cout << "Path is:";
    std::list<Point>::const_iterator pit;
    for (pit = path.begin(); pit != path.end(); ++pit)
      std::cout << " (" << *pit << ")";
    std::cout << std::endl;
  }
  
  return 0;
}
