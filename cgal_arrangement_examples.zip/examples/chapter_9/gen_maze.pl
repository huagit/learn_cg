#!/usr/bin/perl -w

use Getopt::Long;

sub print_rectangle
{
  my $l = $_[0];
  my $r = $_[1];
  my $b = $_[2];
  my $t = $_[3];
  print "4 $l $b $r $b $r $t $l $t\n";
  # print "\\pspolygon*[linecolor=obstacle]($l, $b)($r, $b)($r, $t)($l, $t)\n";
}

my $help = 0;
my $robot_radius = 1;
my $spikes_num = 8;
my $spike_width = 1;
$Getopt::Long::ignorecase = 0;
GetOptions("help" => \$help,
	   "radius=s" => \$robot_radius,
	   "spikes=s" => \$spikes_num) or die "Bad command line option!";
usage() if $help;

my $gap_width = 3 * $robot_radius;
my $left = 0;
my $bottom = 0;
my $right = $spikes_num * $spike_width + ($spikes_num + 1) * $gap_width;
my $top = $spikes_num * $spike_width + ($spikes_num + 1) * $gap_width;

my $obstacles_num = $spikes_num+4;
print "$obstacles_num\n";
for ($i = 0; $i < $spikes_num-1; $i++) {
  $l = $left;
  $b = $bottom + $i * $spike_width + ($i + 1) * $gap_width;
  $r = $right;
  if ($i & 0x1) {
    $l += $gap_width;
  } else {
    $r -= $gap_width;
  }
  $t = $b + $spike_width;
  print_rectangle($l, $r, $b, $t);
}

# The last one leaves a large gap to allow the robots to swap:
$l = $left;
$b = $bottom + $i * $spike_width + ($i + 1) * $gap_width;
$r = $right;
if ($i & 0x1) {
  $l += 2*$gap_width;
} else {
  $r -= 2*$gap_width;
}
$t = $b + $spike_width;
print_rectangle($l, $r, $b, $t);

$l = $left - $spike_width;
$r = $right + $spike_width;
$t = $bottom;
$b = $t - $spike_width;
print_rectangle($l, $r, $b, $t);

$l = $right;
$r = $l + $spike_width;
$t = $top;
$b = $bottom;
print_rectangle($l, $r, $b, $t);

$l = $left - $spike_width;
$r = $right + $spike_width;
$b = $top;
$t = $b + $spike_width;
print_rectangle($l, $r, $b, $t);

$r = $left;
$l = $r - $spike_width;
$t = $top;
$b = $bottom;
print_rectangle($l, $r, $b, $t);

exit(0);

sub usage {
  printf "gen_maze.pl";
  printf "
\t--help\t\t\tprint this help message
\t--radius <radius>\tset robot radius to <radius> (default 1)
\t--spikes <num>\t\tset number of spikes to <num> (default 8)
";
  exit(0);
}
