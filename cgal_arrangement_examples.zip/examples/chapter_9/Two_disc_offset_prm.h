#ifndef CGAL_TWO_DISC_OFFSET_PRM_H
#define CGAL_TWO_DISC_OFFSET_PRM_H

#include <CGAL/basic.h>
#include <CGAL/approximated_offset_2.h>

#include "Two_disc_prm.h"

#define PRM_INV_RELATIVE_CLERANCE  100

template <typename Kernel> class Two_disc_offset_prm  :
  public Two_disc_prm<Kernel> {
private:
  typedef Two_disc_prm<Kernel>                          Base;
  typedef typename Two_disc_prm<Kernel>::Number_type    Number_type;
  typedef typename Two_disc_prm<Kernel>::Obstacle_2     Obstacle;
  
  // Data members:
  Number_type      m_clear1;      // desired clearance for the first robot
  Number_type      m_clear2;      // desired clearance for the second robot

  // Check whether it is possible to connect the configurations associated
  // with the given PRM vertices by a straight line.
  // In case of a valid connection, its total length is also computed.
  bool can_connect(unsigned int u, unsigned int v, double& len,
                   bool /* bound_steps = true */) const
  {
    // Is the straight path plus clearance for the 1st robot collision-free?
    Obstacle path1;
    path1.push_back(this->m_confs[u].pos1);
    path1.push_back(this->m_confs[v].pos1);
    if (this->m_cforb1.do_intersect(approximated_offset_2(path1, m_clear1,
                                                          this->m_eps)))
      return false;

    // Is the straight path plus clearance for the 2nd robot collision-free?
    Obstacle path2;
    path2.push_back(this->m_confs[u].pos2);
    path2.push_back(this->m_confs[v].pos2);
    if (this->m_cforb2.do_intersect(approximated_offset_2(path2, m_clear2,
                                                          this->m_eps)))
      return false;
    
    // Assuming the first robot moves at constant speed from u_pos1 to v_pos1
    // while the second one moves at constant speed from u_pos2 to v_pos2
    // from time t = 0 to time t = 1, find the time when the distance between
    // them is minimal.
    // The squared distance D between the robots at time t is given by:
    //   D(t) = alpha*t^2 + 2*beta*t + gamma.
    const Number_type ux1 = this->m_confs[u].pos1.x();
    const Number_type uy1 = this->m_confs[u].pos1.y();
    const Number_type vx1 = this->m_confs[v].pos1.x();
    const Number_type vy1 = this->m_confs[v].pos1.y();
    const Number_type ux2 = this->m_confs[u].pos2.x();
    const Number_type uy2 = this->m_confs[u].pos2.y();
    const Number_type vx2 = this->m_confs[v].pos2.x();
    const Number_type vy2 = this->m_confs[v].pos2.y();
    const Number_type dx = ux2 - ux1, dy = uy2 - uy1;
    const Number_type rx1 = vx1 - ux1, rx2 = vx2 - ux2;
    const Number_type ry1 = vy1 - uy1, ry2 = vy2 - uy2;
    const Number_type dlx = rx2 - rx1, dly = ry2 - ry1;
    const Number_type alpha = dlx*dlx + dly*dly;
    const Number_type beta = dx*dlx + dy*dly;
    const Number_type gamma = dx*dx + dy*dy;
    const Number_type t_min = - beta / alpha;

    if ((CGAL::sign(t_min) == CGAL::POSITIVE) &&
        (CGAL::compare(t_min, 1) == CGAL::SMALLER))
    {
      // We found a valid value 0 < t_min < 1, so the minimal squared
      // distance is given by D(t_min).
      const Number_type   min_sqr_dist = (alpha*t_min + 2*beta)*t_min + gamma;
      bool rc = (CGAL::compare(CGAL::square(this->m_rad1 + this->m_rad2),
                               min_sqr_dist) == CGAL::SMALLER);
      if (rc) {
        const double dist1 = CGAL::sqrt(CGAL::square(CGAL::to_double(rx1)) +
                                        CGAL::square(CGAL::to_double(ry1)));
        const double dist2 = CGAL::sqrt(CGAL::square(CGAL::to_double(rx2)) +
                                    CGAL::square(CGAL::to_double(ry2)));
        len = dist1 + dist2;
      }
      return rc;
    }

    // The straight-line connection is collision-free and its length equals
    // the square root of the sum of pairwise distances.
    const double dist1 = CGAL::sqrt(CGAL::square(CGAL::to_double(rx1)) +
                                    CGAL::square(CGAL::to_double(ry1)));
    const double dist2 = CGAL::sqrt(CGAL::square(CGAL::to_double(rx2)) +
                                    CGAL::square(CGAL::to_double(ry2)));
    len = dist1 + dist2;
    return true;
  }

public:
  // Constructor:
  // bbox is a bounding box for the entire scene.
  // [begin, end) specify the range of input obstacles (of type Obstacle).
  // radius1, radius2 are the radii of the two disc robots.
  // n_vertices, n_edges specify the required dimensions of the PRM.
  template <typename ObstacleIterator>
  Two_disc_offset_prm(const CGAL::Bbox_2& bbox,
                      ObstacleIterator begin, ObstacleIterator end,
                      const Number_type& radius1, const Number_type& radius2,
                      unsigned int n_vertices, unsigned int n_edges) :
    Base(bbox, begin, end, radius1, radius2, n_vertices, n_edges)
  {
    // Compute the desired clearance for each robot, given as a fraction of
    // its radius.
    m_clear1 = radius1 / PRM_INV_RELATIVE_CLERANCE; /* \label{lst:prm:clear1} */
    m_clear2 = radius2 / PRM_INV_RELATIVE_CLERANCE; /* \label{lst:prm:clear2} */

    this->generate_prm(n_vertices, n_edges);
  }
};

#endif
