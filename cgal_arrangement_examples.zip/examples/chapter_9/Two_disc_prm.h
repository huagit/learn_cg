#ifndef CGAL_TWO_DISC_PRM_H
#define CGAL_TWO_DISC_PRM_H

#include <vector>

#include <boost/graph/graph_traits.hpp>
#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/dijkstra_shortest_paths.hpp>
#include <boost/graph/depth_first_search.hpp>

#include <CGAL/basic.h>
#include <CGAL/Gps_circle_segment_traits_2.h>
#include <CGAL/General_polygon_set_2.h>
#include <CGAL/approximated_offset_2.h>
#include <CGAL/Random.h>

#include "numerical_cast.h"

#define PRM_OFFSET_EPS             0.000001

// Representation of a configuration (the positions of the two discs).
template <typename Kernel> struct Configuration_4 {
  typename Kernel::Point_2 pos1;        // the location of the first robot
  typename Kernel::Point_2 pos2;        // the location of the second robot
};

template <typename Kernel> class Two_disc_prm {
public:
  typedef typename Kernel::FT                           Number_type;
  typedef typename Kernel::Point_2                      Position_2;
  typedef CGAL::Polygon_2<Kernel>                       Obstacle_2;
  typedef Configuration_4<Kernel>                       Conf_4;
  
  // Representation of the PRM graph.
  typedef boost::adjacency_list<boost::vecS, boost::vecS, boost::undirectedS,
                                boost::no_property,
                                boost::property<boost::edge_weight_t, double> >
                                                                 Graph;
  typedef boost::graph_traits<Graph>::edge_descriptor            Edge;
  typedef boost::property_map<Graph, boost::edge_weight_t>::type Weight_map;

  // Constructor:
  // bbox is a bounding box for the entire scene.
  // [begin, end) specify the range of input obstacles (of type Obstacle_2).
  // radius1, radius2 are the radii of the two disc robots.
  // n_vertices, n_edges specify the required dimensions of the PRM.
  template <typename ObstacleIterator>
  Two_disc_prm(const CGAL::Bbox_2& bbox,
               ObstacleIterator begin, ObstacleIterator end,
               const Number_type& radius1, const Number_type& radius2,
               unsigned int n_vertices, unsigned int n_edges) :
    m_bbox(bbox),
    m_rad1(radius1), m_rad2(radius2),
    m_num_verts(n_vertices), m_num_edges(0),
    m_confs(n_vertices + 2), m_prm(n_vertices + 2)
  {
    // Get the maximal dimension (width or height) of the bounding box.
    const double  b_width = bbox.xmax() - bbox.xmin();
    const double  b_height = bbox.ymax() - bbox.ymin();
    const double  max_dim = (b_width > b_height) ? b_width : b_height;

    m_eps = PRM_OFFSET_EPS * max_dim;

    // Compute the (approximated) forbidden configuration space for
    // each separate robot.
    compute_cforb(begin, end, m_rad1, m_cforb1);
    compute_cforb(begin, end, m_rad2, m_cforb2);
  }

  // Get the number of PRM vertices.
  unsigned int number_of_vertices() const { return (m_num_verts); }

  // Get the number of PRM edges.
  unsigned int number_of_edges() const { return (m_num_edges); }

  // Plan a collision-free motion path if exists for the two disc robots,
  // starting from the given start configuration s and going to the goal
  // configuration g.
  // The path is returned as a sequence of configurations, such that the
  // motion-path of each robot is piecewise linear.
  // The function returns a past-the-end iterator for the sequence.
  template <typename Output_iterator>
  Output_iterator query(const Conf_4& s, const Conf_4& g, Output_iterator oi)
  {
    // Clear any edges incident to the PRM vertices representing the source
    // configuration and the goal configuration.
    const unsigned int  s_index = 0;
    const unsigned int  g_index = m_num_verts + 1;

    boost::clear_vertex(s_index, m_prm);
    boost::clear_vertex(g_index, m_prm);

    // Set the source and goal configurations.
    m_confs[s_index] = s;
    m_confs[g_index] = g;

    // If the source or the goal configurations are not free, indicate that
    // there is no possible collision-free path.
    if (! is_free(m_confs[s_index]) || ! is_free(m_confs[g_index])) return oi;

    // Try to connect the source and goal configurations directly.
    double len;
    if (can_connect(s_index, g_index, len, false)) {
      *oi++ = m_confs[s_index];
      *oi++ = m_confs[g_index];
      return oi;
    }

    // Try to connect the source and goal configurations with the PRM vertices.
    unsigned int v, sc = 0, gc = 0;
    for (v = 1; v <= m_num_verts; ++v) {
      // Try to connect the source configuration with v.
      if (can_connect(s_index, v, len)) {
        std::pair<Edge, bool>  e = boost::add_edge(s_index, v, m_prm);
        m_wgt_map[e.first] = len;
        ++sc;
      }

      // Try to connect the goal configuration with v.
      if (can_connect(g_index, v, len)) {
        std::pair<Edge, bool>  e = boost::add_edge(g_index, v, m_prm);
        m_wgt_map[e.first] = len;
        ++gc;
      }
    }

    // Perform a Dijkstra search from the vertex representing the source
    // configuration and look for the shortest path to the goal configuration.
    std::vector<unsigned int>  preds(boost::num_vertices(m_prm));

    boost::dijkstra_shortest_paths(m_prm, s_index,
                                   boost::predecessor_map(&preds[0]));

    // The goal configuration is unreachable from the source:
    if (preds[g_index] == g_index) return oi;  

    // According to the predecessor information, prepare a list of vertices
    // that occur on the shortest path from the source to the goal.
    std::list<unsigned int>   path_verts;
    for (v = g_index; v != s_index; v = preds[v])
      path_verts.push_front(v);
    path_verts.push_front(s_index);

    // Output the sequence of intermediate configurations that constitute the
    // shortest collision-free motion-path we have computed.
    std::list<unsigned int>::iterator  it;
    for (it = path_verts.begin(); it != path_verts.end(); ++it)
      *oi++ = m_confs[*it];
    return oi;
  }

protected:
  typedef CGAL::Gps_circle_segment_traits_2<Kernel>     Traits_2;
  typedef typename Traits_2::Point_2                    Point_2;
  typedef typename Traits_2::Polygon_with_holes_2       CSpace_obstacle_2;
  typedef CGAL::General_polygon_set_2<Traits_2>         CSpace_forb_2;

  // Data members:
  CGAL::Bbox_2     m_bbox;        // the bounding box of the scene
  Number_type      m_rad1;        // the radius of the first robot
  Number_type      m_rad2;        // the radius of the second robot
  CSpace_forb_2    m_cforb1;      // forbidden C-space for the first robot
  CSpace_forb_2    m_cforb2;      // forbidden C-space for the second robot
  double           m_eps;         // error bound for offset approximation
  unsigned int                  m_num_verts; // number of PRM vertices
  unsigned int                  m_num_edges; // number of PRM edges
  std::vector<Conf_4>           m_confs;     // configurations of PRM vertices
  Graph                         m_prm;       // the PRM graph
  Weight_map                    m_wgt_map;   // a weight map for the PRM edges

  // Check whether it is possible to connect the configurations associated
  // with the given PRM vertices by a straight line.
  // In case of a valid connection, its total length is also computed.
  virtual bool can_connect(unsigned int u, unsigned int v, double& len,
                           bool bound_steps = true) const = 0;

  // Generate the PRM.
  void generate_prm(unsigned int n_vertices, unsigned int n_edges)
  {
    // Create the required number of vertices, where each vertex represents
    // a free configuration of the two robots.
    CGAL::Random         rand;
    unsigned int         k = 0;
    while (k < n_vertices) {
      Conf_4  conf;
      
      // Pick a random position for the first robot and check if it is free.
      double x1 = rand.get_double(m_bbox.xmin(), m_bbox.xmax());
      double y1 = rand.get_double(m_bbox.ymin(), m_bbox.ymax());
      conf.pos1 = Position_2(to_rational(x1), to_rational(y1));
      if (is_in_cforb(m_cforb1, conf.pos1)) continue;
    
      // Pick a free random position for the second robot.
      do {
        double x2 = rand.get_double(m_bbox.xmin(), m_bbox.xmax());
        double y2 = rand.get_double(m_bbox.ymin(), m_bbox.ymax());
        conf.pos2 = Position_2(to_rational(x2), to_rational(y2));
      } while (is_in_cforb(m_cforb2, conf.pos2));

      // Make sure that the two robots do not intersect one another.
      if (do_intersect(conf.pos1, m_rad1, conf.pos2, m_rad2)) continue;

      // If we reached here, the configuration is free - store it.
      m_confs[++k] = conf;
    }

    // Create the PRM edges trying to connect random pairs of configurations.
    m_wgt_map = boost::get(boost::edge_weight, m_prm);
    for (k = 0; (m_num_edges < n_edges) && (k < n_vertices*n_vertices); ++k) {
      // Pick two random vertices and make sure they are still disconnected.
      unsigned int u = rand.get_int(0, n_vertices) + 1;
      unsigned int v = rand.get_int(0, n_vertices) + 1;
      if (u == v || (boost::edge(u, v, m_prm)).second) continue;

      // If the two configurations are connectable, set an edge in the PRM.
      double len;
      if (can_connect(u, v, len)) {
        std::pair<Edge, bool>  e = boost::add_edge(u, v, m_prm);
        m_wgt_map[e.first] = len; 
        ++m_num_edges;
      }
    }
  }
  
  // Convert a double-precision value to a rational number.
  Number_type to_rational(const double& val)
  {
    // Assume there are at most 6 decimal digits after the decimal point.
    return numerical_cast<Number_type, 1000000> (val);
  }

  // Compute the forbidden configuration space for a robot of a given radius
  // moving amidst a given range of polygonal workspace obstacles.
  template <typename ObstacleIterator>
  void compute_cforb(ObstacleIterator begin, ObstacleIterator end,
                     const Number_type& radius, CSpace_forb_2& cforb)
  {
    // Go over the set of workspace obstacles and approximate the offset of
    // each polygon by the radius of the robot.
    ObstacleIterator              it;
    std::list<CSpace_obstacle_2>  cspace_obstacles;
    for (it = begin; it != end; ++it)
      cspace_obstacles.push_back(CGAL::approximated_offset_2(*it, radius, m_eps));

    // Compute the union of the offset polygons to obtain the forbidden
    // configuration space.
    cforb.join(cspace_obstacles.begin(), cspace_obstacles.end());
  }

  // Check if the given position is in the forbidden configuration space.
  bool is_in_cforb(const CSpace_forb_2& cforb, const Position_2& q) const
  {
    return (cforb.oriented_side(Point_2(q.x(), q.y())) !=
            CGAL::ON_NEGATIVE_SIDE);
  }

  // Check whether two disc robots of given radii intersect when placed at
  // the given positions.
  bool do_intersect(const Position_2& pos1, const Number_type& radius1,
                    const Position_2& pos2, const Number_type& radius2) const
  {
    // If the distance between the two robot centers is not larger than the
    // sum of their radii, then the robots intersect. We consider the squared
    // values to avoid a square-root operation.
    const Number_type dx = pos2.x() - pos1.x();
    const Number_type dy = pos2.y() - pos1.y();
    return (CGAL::compare(dx*dx + dy*dy, CGAL::square(radius1 + radius2)) !=
            CGAL::LARGER);
  }

  // Check if the given configuration is free.
  bool is_free(const Conf_4& conf) const
  {
    return (! is_in_cforb(m_cforb1, conf.pos1) &&
            ! is_in_cforb(m_cforb2, conf.pos2) &&
            ! do_intersect(conf.pos1, m_rad1, conf.pos2, m_rad2));
  }

public:
  template <typename Visitor> void dfs_prm(Visitor& vis)
  { boost::depth_first_search(m_prm, boost::visitor(vis)); }

  const CSpace_forb_2& cforb1() const { return m_cforb1; }
  const CSpace_forb_2& cforb2() const { return m_cforb2; }
  const std::vector<Conf_4>& confs() const { return m_confs; }
  const Graph& prm() const { return m_prm; }
};

#endif
