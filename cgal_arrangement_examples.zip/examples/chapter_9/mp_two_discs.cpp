// File: mp_two_discs.cpp

#include <iostream>
#include <sstream>
#include <string>
#include <list>
#include <boost/timer.hpp>
#include <boost/lexical_cast.hpp>

#include <CGAL/Cartesian.h>
#include <CGAL/Gmpq.h>

#include "read_objects.h"
#include "bbox.h"
#include "Two_disc_offset_prm.h"

typedef CGAL::Cartesian<CGAL::Gmpq>                     Kernel;
typedef Kernel::FT                                      Number_type;
typedef Kernel::Point_2                                 Position;
typedef CGAL::Polygon_2<Kernel>                         Obstacle;
typedef std::list<Obstacle>                             Obstacle_set;
typedef Two_disc_offset_prm<Kernel>                     PRM;

// The query type.
struct Query { Configuration_4<Kernel> m_s, m_g; };

// Read a single query.
std::istream& operator>> (std::istream& is, Query& q)
{ return is >> q.m_s.pos1 >> q.m_s.pos2 >> q.m_g.pos1 >> q.m_g.pos2; }

// The main application:
int main(int argc, char* argv[])
{
  if (argc < 7) {
    std::cout << "Usage: " << argv[0]
              << " <obstacle file> <radius 1> <radius 2>"
              << " <# PRM vertices> <# PRM edges> <query file>" << std::endl;
    return -1;
  }

  // Read the polygonal obstacles from the input file.
  Obstacle_set  obstacles;
  read_objects<Obstacle>(argv[1], std::back_inserter(obstacles));

  // Construct the bounding box obstacles.
  CGAL::Bbox_2  bb = bbox(obstacles.begin(), obstacles.end());
 
  // Construct the PRM according to the command-line parameters.
  Number_type  radius1, radius2;
  std::istringstream iss1(argv[2], std::istringstream::in); iss1 >> radius1;
  std::istringstream iss2(argv[3], std::istringstream::in); iss2 >> radius2;
  const unsigned int n_vertices = boost::lexical_cast<unsigned int>(argv[4]);
  const unsigned int n_edges = boost::lexical_cast<unsigned int>(argv[5]);
  std::cout << "Constructing the PRM ... " << std::flush;
  boost::timer timer;
  PRM prm(bb, obstacles.begin(), obstacles.end(), radius1, radius2,
          n_vertices, n_edges);
  double secs = timer.elapsed();
  std::cout << "Done!" << std::endl
            << "  PRM has " << prm.number_of_vertices() << " vertices and "
            << prm.number_of_edges() << " edges." << std::endl
            << "  Construction took " << secs << " sec." << std::endl;

  // Read the queries.
  std::list<Query> queries;
  read_objects<Query>(argv[6], std::back_inserter(queries));

  std::list<Query>::const_iterator it;
  for (it = queries.begin(); it != queries.end(); ++it) {
    // Use the PRM to plan a collision-free motion path.
    std::list<Configuration_4<Kernel> > path;
    prm.query(it->m_s, it->m_g, std::back_inserter(path));
    if (path.empty()) {
      std::cout << "  No path found!" << std::endl;
      continue;
    }

    // Print the collision-free path.
    std::cout << "  Found a path with " << path.size() - 2
              << " intermediate configuration(s)." << std::endl;
    path.clear();
  }
  return 0;
}
