#ifndef CGAL_TWO_DISC_SIMPLE_PRM_H
#define CGAL_TWO_DISC_SIMPLE_PRM_H

#include <CGAL/basic.h>
#include <CGAL/approximated_offset_2.h>

#include "Two_disc_prm.h"

#define PRM_RELATIVE_STEP_SIZE  0.001
#define PRM_LEN_RATIO           0.1

template <typename Kernel> class Two_disc_simple_prm :
  public Two_disc_prm<Kernel> {
private:
  typedef Two_disc_prm<Kernel>                          Base;
  typedef typename Two_disc_prm<Kernel>::Number_type    Number_type;
  typedef typename Two_disc_prm<Kernel>::CSpace_forb_2  CSpace_forb;
  typedef typename Two_disc_prm<Kernel>::Position_2     Position;
  
  // Data members:
  double         m_delta;       // the step size
  Number_type    m_inf_rad1;    // the first radius + delta/2
  Number_type    m_inf_rad2;    // the second radius + delta/2
  CSpace_forb    m_cforb1_plus; // C_forb for the inflated first robot
  CSpace_forb    m_cforb2_plus; // C_forb for the inflated second robot
  int            m_max_steps;   // maximial number of samples
  
  // Check whether it is possible to connect the configurations associated
  // with the given PRM vertices by a straight line.
  // In case of a valid connection, its total length is also computed.
  bool can_connect(unsigned int u, unsigned int v, double& len,
                   bool bound_steps = true) const
  {
    // Compute the distances between the two pairs of positions, and
    // evaluate the number of intermediate configurations we have to sample.
    const Number_type rx1 = this->m_confs[v].pos1.x()-this->m_confs[u].pos1.x();
    const Number_type ry1 = this->m_confs[v].pos1.y()-this->m_confs[u].pos1.y();
    const Number_type rx2 = this->m_confs[v].pos2.x()-this->m_confs[u].pos2.x();
    const Number_type ry2 = this->m_confs[v].pos2.y()-this->m_confs[u].pos2.y();
    const double      dx1 = CGAL::to_double(rx1);
    const double      dy1 = CGAL::to_double(ry1);
    const double      dx2 = CGAL::to_double(rx2);
    const double      dy2 = CGAL::to_double(ry2);
    const double      dist1 = CGAL::sqrt(dx1*dx1 + dy1*dy1);
    const double      dist2 = CGAL::sqrt(dx2*dx2 + dy2*dy2);
    const int         n1 = static_cast<unsigned int>(dist1 / m_delta);
    const int         n2 = static_cast<unsigned int>(dist2 / m_delta);
    const int         n_steps = (n1 > n2) ? n1 : n2;
    
    // Do not attemp to connect configurations that lie too far from each other.
    if (bound_steps && (n_steps > m_max_steps)) return false;

    // Sample the straight-line connection between the two configurations
    // and verify that each intermediate configuration is collision-free.
    const Number_type sx1 = rx1 / n_steps;
    const Number_type sy1 = ry1 / n_steps;
    const Number_type sx2 = rx2 / n_steps;
    const Number_type sy2 = ry2 / n_steps;
    for (int k = 0; k <= n_steps; ++k) {
      const Number_type rk = k;
      // The positions of the robots at the k'th intermediate configuration.
      Position p1(this->m_confs[u].pos1.x() + k*sx1,
                  this->m_confs[u].pos1.y() + k*sy1);
      Position p2(this->m_confs[u].pos2.x() + k*sx2,
                  this->m_confs[u].pos2.y() + k*sy2);

      // Check that the configuration <p1, p2> is collision-free. We use the
      // inflated forbidden spaces to account for the gap between samples.
      if (is_in_cforb(m_cforb1_plus, p1) || is_in_cforb(m_cforb2_plus, p2) ||
          do_intersect(p1, m_inf_rad1, p2, m_inf_rad2))
        return false;
    }

    // If we reached here, the straight-line connection is collision-free,
    // and its length equals the sum of pairwise distances.
    len = dist1 + dist2;
    return true;
  }

public:
  // Constructor:
  // bbox is a bounding box for the entire scene.
  // [begin, end) specify the range of input obstacles (of type Obstacle).
  // radius1, radius2 are the radii of the two disc robots.
  // n_vertices, n_edges specify the required dimensions of the PRM.
  template <typename ObstacleIterator>
  Two_disc_simple_prm(const CGAL::Bbox_2& bbox,
                      ObstacleIterator begin, ObstacleIterator end,
                      const Number_type& radius1, const Number_type& radius2,
                      unsigned int n_vertices, unsigned int n_edges) :
    Base(bbox, begin, end, radius1, radius2, n_vertices, n_edges)
  {
    const double  b_width = bbox.xmax() - bbox.xmin();
    const double  b_height = bbox.ymax() - bbox.ymin();
    const double  max_dim = (b_width > b_height) ? b_width : b_height;

    // Compute the forbidden configuration spaces for the two robots inflated
    // by delta/2, where delta is the step size we take when verifying simple
    // motion paths.
    m_delta = PRM_RELATIVE_STEP_SIZE * max_dim;
    
    m_inf_rad1 = this->m_rad1 + this->to_rational(m_delta)/2;
    compute_cforb(begin, end, m_inf_rad1, m_cforb1_plus);
    m_inf_rad2 = this->m_rad2 + this->to_rational(m_delta)/2;
    compute_cforb(begin, end, m_inf_rad2, m_cforb2_plus);

    // The maximal distance between two vertices equals the length of the
    // bounding-box diagonal. We do not try to connect configurations the
    // distance between them is more than LEN_RATIO times this length.
    m_max_steps = static_cast<unsigned int>
      (PRM_LEN_RATIO * CGAL::sqrt(b_width*b_width + b_height*b_height) /
       m_delta);

    this->generate_prm(n_vertices, n_edges);
  }
};

#endif
