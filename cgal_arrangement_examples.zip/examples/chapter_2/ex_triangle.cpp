// File: ex_triangle.cpp

#include <CGAL/Cartesian.h>
#include <CGAL/Arr_non_caching_segment_traits_2.h>
#include <CGAL/Arrangement_2.h>

typedef int                                             Number_type;
typedef CGAL::Cartesian<Number_type>                    Kernel;
typedef CGAL::Arr_non_caching_segment_traits_2<Kernel>  Traits;
typedef Traits::Point_2                                 Point;
typedef Traits::X_monotone_curve_2                      Segment;
typedef CGAL::Arrangement_2<Traits>                     Arrangement;

int main()
{
  Point        p1(1, 1), p2(1, 2), p3(2, 1);
  Segment      cv[] = {Segment(p1, p2), Segment(p2, p3), Segment(p3, p1)};
  Arrangement  arr;
  insert(arr, &cv[0], &cv[sizeof(cv)/sizeof(Segment)]);
  std::cout << "Number of faces: " << arr.number_of_faces() << std::endl;
  return 0;
}
