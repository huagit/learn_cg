#ifndef LESS_THAN_HANDLE_H
#define LESS_THAN_HANDLE_H

// A functor that compares handles.
struct Less_than_handle {
  template <typename Type>
  bool operator()(Type s1, Type s2) const { return (&(*s1) < &(*s2)); }
};

#endif
