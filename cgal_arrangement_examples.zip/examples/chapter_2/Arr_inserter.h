#ifndef ARR_INSERTER_H
#define ARR_INSERTER_H

#include <CGAL/basic.h>

#include "Less_than_handle.h"

template <typename Polyhedron, typename Arrangement> class Arr_inserter {
private:
  typedef typename Polyhedron::Halfedge_const_handle
    Polyhedron_halfedge_const_handle;
  typedef std::map<typename Polyhedron::Vertex_const_handle,
                   typename Arrangement::Vertex_handle, Less_than_handle>
                                                          Vertex_map;
  typedef typename Vertex_map::iterator                   Vertex_map_iterator;
  typedef typename Arrangement::Point_2                   Point_2;
  typedef typename Arrangement::X_monotone_curve_2        X_monotone_curve_2;
  
  Vertex_map m_vertex_map;
  std::set<Polyhedron_halfedge_const_handle, Less_than_handle> m_edges;
  const typename Arrangement::Traits_2::Compare_xy_2 m_cmp_xy;
  const typename Arrangement::Traits_2::Equal_2 m_equal;
  
public:
  Arr_inserter(const typename Arrangement::Traits_2& traits) :
    m_cmp_xy(traits.compare_xy_2_object()),
    m_equal(traits.equal_2_object())
  {}
  
  void operator()(Arrangement& arr, Polyhedron_halfedge_const_handle he,
                  Point_2& prev_arr_point, Point_2& arr_point)
  {
    // Avoid the insertion if he or its twin have already been inserted.
    if ((m_edges.find(he) != m_edges.end()) ||
        (m_edges.find(he->opposite()) != m_edges.end()))
      return;

    // Locate the arrangement vertices, which correspond to the projected
    // polyhedron vertices, and insert the segment corresponding to the
    // projected-polyhedron edge using the proper specialized insertion
    // function.
    m_edges.insert(he);
    X_monotone_curve_2 curve(prev_arr_point, arr_point);
    Vertex_map_iterator it1 = m_vertex_map.find(he->opposite()->vertex());
    Vertex_map_iterator it2 = m_vertex_map.find(he->vertex());
    if (it1 != m_vertex_map.end()) {
      if (it2 != m_vertex_map.end())
        arr.insert_at_vertices(curve, (*it1).second, (*it2).second);
      else {
        typename Arrangement::Halfedge_handle arr_he =
          (m_cmp_xy(prev_arr_point, arr_point) == CGAL::SMALLER) ?
          arr.insert_from_left_vertex(curve, (*it1).second) :
          arr.insert_from_right_vertex(curve, (*it1).second);
        m_vertex_map[he->vertex()] = arr_he->target();  // map the new vertex
      }
    }
    else if (it2 != m_vertex_map.end()) {
      typename Arrangement::Halfedge_handle arr_he =
        (m_cmp_xy(prev_arr_point, arr_point) == CGAL::LARGER) ?
        arr.insert_from_left_vertex(curve, (*it2).second) :
        arr.insert_from_right_vertex(curve, (*it2).second);
      // map the new vertex.
      m_vertex_map[he->opposite()->vertex()] = arr_he->target();
    }
    else {
      typename Arrangement::Halfedge_handle arr_he = 
        arr.insert_in_face_interior(curve, arr.unbounded_face());
      // map the new vertices.      
      if (m_equal(prev_arr_point, arr_he->source()->point())) {
        m_vertex_map[he->opposite()->vertex()] = arr_he->source();
        m_vertex_map[he->vertex()] = arr_he->target();
      } else {
        m_vertex_map[he->opposite()->vertex()] = arr_he->target();
        m_vertex_map[he->vertex()] = arr_he->source();
      }
    }
  }
};

#endif
