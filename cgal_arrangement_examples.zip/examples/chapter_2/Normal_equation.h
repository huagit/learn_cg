#ifndef NORMAL_EQUATION_H
#define NORMAL_EQUATION_H

// A functor that computes the equation of the normal to a facet.
struct Normal_equation {
  template <typename Facet> typename Facet::Plane_3 operator()(Facet & f) {
    typename Facet::Halfedge_handle h = f.halfedge();
    return CGAL::cross_product(h->next()->vertex()->point() -
                               h->vertex()->point(),
                               h->next()->next()->vertex()->point() -
                               h->next()->vertex()->point());
  }
};

#endif
