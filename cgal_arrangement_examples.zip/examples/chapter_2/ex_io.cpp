// File: ex_io.cpp

#include <fstream>

#include <CGAL/basic.h>
#include <CGAL/IO/Arr_iostream.h>

#include "arr_inexact_construction_segments.h"
#include "arr_print.h"

int main()
{
  // Construct the arrangement.
  Point           p1(1, 3), p2(3, 5), p3(5, 3), p4(3, 1);
  Segment         s1(p1, p2), s2(p2, p3), s3(p3, p4), s4(p4, p1), s5(p1, p3);

  Arrangement     arr1;
  Halfedge_handle e1 = arr1.insert_in_face_interior(s1, arr1.unbounded_face());
  Vertex_handle   v1 = e1->source();
  Vertex_handle   v2 = e1->target();
  Halfedge_handle e2 = arr1.insert_from_left_vertex(s2, v2);
  Vertex_handle   v3 = e2->target();
  Halfedge_handle e3 = arr1.insert_from_right_vertex(s3, v3);
  Vertex_handle   v4 = e3->target();
  Halfedge_handle e4 = arr1.insert_at_vertices(s4, v4, v1);
  Halfedge_handle e5 = arr1.insert_at_vertices(s5, v1, v3);

  // Write the arrangement to a file.
  std::cout << "Writing" << std::endl;
  print_arrangement_size(arr1);
  std::ofstream  out_file("arr_ex_io.dat");
  out_file << arr1;
  out_file.close();

  // Read the arrangement from the file.
  Arrangement      arr2;
  std::ifstream    in_file("arr_ex_io.dat");
  in_file >> arr2;
  in_file.close();
  std::cout << "Reading" << std::endl;
  print_arrangement_size(arr2);

  return 0;
}

