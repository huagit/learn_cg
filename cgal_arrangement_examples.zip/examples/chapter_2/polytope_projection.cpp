// File: ex_polytope_projection.cpp

#include <set>
#include <map>

#include "arr_inexact_construction_segments.h"
#include "read_objects.h"
#include "arr_print.h"
#include "Normal_equation.h"
#include "Arr_inserter.h"

#include <CGAL/convex_hull_3.h>
#include <CGAL/Polyhedron_traits_with_normals_3.h>

typedef CGAL::Polyhedron_traits_with_normals_3<Kernel>  Polyhedron_traits;
typedef CGAL::Polyhedron_3<Polyhedron_traits>           Polyhedron;
typedef Kernel::Point_3                                 Point_3;

int main(int argc, char* argv[])
{
  // Read a sequence of 3D points.
  const char* filename = (argc > 1) ? argv[1] : "polytope.dat";
  std::list<Point_3> points;
  read_objects<Point_3>(filename, std::back_inserter(points));

  // Construct the polyhedron.
  Polyhedron polyhedron;
  CGAL::convex_hull_3(points.begin(), points.end(), polyhedron);
  // Compute the normals to all polyhedron facets.
  std::transform(polyhedron.facets_begin(), polyhedron.facets_end(),
                 polyhedron.planes_begin(), Normal_equation());

  // Construct the projection: go over all polyhedron facets.
  Traits traits;
  Arrangement arr(&traits);
  Kernel kernel;
  Kernel::Compare_z_3 cmp_z = kernel.compare_z_3_object();
  Kernel::Construct_translated_point_3 translate =
    kernel.construct_translated_point_3_object();
  Point_3 origin = kernel.construct_point_3_object()(CGAL::ORIGIN);
  Arr_inserter<Polyhedron, Arrangement> arr_inserter(traits);
  Polyhedron::Facet_const_iterator it;
  for (it = polyhedron.facets_begin(); it != polyhedron.facets_end(); ++it) {
    // Discard facets whose normals have a non-positive z-components.
    if (cmp_z(translate(origin, it->plane()), origin) != CGAL::LARGER)
      continue;

    // Traverse the halfedges along the boundary of the current facet.
    Polyhedron::Halfedge_around_facet_const_circulator hit = it->facet_begin();
    const Point_3& prev_point = hit->vertex()->point();
    Point prev_arr_point = Point(prev_point.x(), prev_point.y());
    for (++hit; hit != it->facet_begin(); ++hit) {
      const Point_3& point = hit->vertex()->point();
      Point arr_point = Point(point.x(), point.y());
      arr_inserter(arr, hit, prev_arr_point, arr_point);
      prev_arr_point = arr_point;
    }
    const Point_3& point = hit->vertex()->point();
    Point arr_point = Point(point.x(), point.y());
    arr_inserter(arr, hit, prev_arr_point, arr_point);
    prev_arr_point = arr_point;
  }
  polyhedron.clear();

  // Remove internal edges.
  Face_handle unb_face = arr.unbounded_face();
  Arrangement::Edge_iterator eit;
  for (eit = arr.edges_begin(); eit != arr.edges_end(); ++eit) {
    Halfedge_handle he = eit;
    if ((he->face() != unb_face) && (he->twin()->face() != unb_face))
      arr.remove_edge(eit);
  }

  print_arrangement(arr);
  return 0;
}
