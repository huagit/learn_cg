// File: ex_traits_adaptor.cpp

#include <iostream>
#include <list>
#include <boost/timer.hpp>

#include "arr_Bezier.h"
#include "read_objects.h"

#include <CGAL/Gps_traits_2.h>
#include <CGAL/Boolean_set_operations_2.h>

typedef CGAL::Gps_traits_2<Traits>                    Gps_traits;
typedef Gps_traits::General_polygon_2                 Polygon;
typedef Gps_traits::General_polygon_with_holes_2      Polygon_with_holes;
typedef std::list<Polygon_with_holes>                 Polygon_set;

// Read a general polygon with holes formed by Bezier curves from the file.
bool read_Bezier_polygon(const char* filename, Polygon_with_holes& P)
{
  // Read the Bezier curves.
  std::list<Bezier_curve>  curves;
  read_objects<Bezier_curve>(filename, std::back_inserter(curves));
  
  // Read the curves and construct the general polygon these curves form.
  std::list<Traits::X_monotone_curve_2> xcvs;
  bool                 first = true;
  Rat_point            p0;
  std::list<Polygon>   pgns;
  Rat_kernel kernel;
  const Rat_kernel::Equal_2 equal = kernel.equal_2_object();
  Traits traits;
  Traits::Make_x_monotone_2 mk_x_monotone = traits.make_x_monotone_2_object();
  std::list<Bezier_curve>::const_iterator it;
  for (it = curves.begin(); it != curves.end(); ++it) {
    std::list<CGAL::Object> x_objs;
    mk_x_monotone(*it, std::back_inserter(x_objs));
    
    std::list<CGAL::Object>::const_iterator  xoit;
    for (xoit = x_objs.begin(); xoit != x_objs.end(); ++xoit) {
      Traits::X_monotone_curve_2 xcv;
      if (CGAL::assign(xcv, *xoit)) xcvs.push_back(xcv);
    }
    
    // Check whether the current curve closes a polygon; namely, whether its
    // target point (the last control point) equals the source of the first
    // curve in the current chain.
    if (first) {
      // This is the first curve in the chain - store its source point.
      p0 = it->control_point(0);
      first = false;
      continue;
    }
    if (equal(p0, it->control_point(it->number_of_control_points() - 1))) {
      // Push a new polygon into the polygon list. Make sure that the polygon
      // is counterclockwise-oriented if it represents the outer boundary
      // and clockwise-oriented if it represents a hole.
      Polygon            pgn(xcvs.begin(), xcvs.end());
      CGAL::Orientation  orient = pgn.orientation();
        
      if ((pgns.empty() && orient == CGAL::CLOCKWISE) ||
          (! pgns.empty() && orient == CGAL::COUNTERCLOCKWISE))
        pgn.reverse_orientation();
        
      pgns.push_back(pgn);
      xcvs.clear();
      first = true;
    }
  }

  if (! xcvs.empty()) return false;

  // Construct the polygon with holes.
  std::list<Polygon>::iterator pit = pgns.begin();
  // The first polygon is the outer boundary and the rest are the holes.
  P = Polygon_with_holes(pgns.front(), ++pit, pgns.end());
  return true;
}

// The main program.
int main(int argc, char* argv[])
{
  // Get the name of the input files from the command line, or use the default
  // char_g.dat and char_m.dat files if no command-line parameters are given.
  const char* filename1 = (argc > 1) ? argv[1] : "char_g.dat";
  const char* filename2 = (argc > 2) ? argv[2] : "char_m.dat";

  // Read the general polygons from the input files.
  Polygon_with_holes  P1, P2;

  boost::timer timer;
  if (! read_Bezier_polygon(filename1, P1)) {
    std::cerr << "Failed to read " << filename1 << " ..." << std::endl;
    return -1;
  }

  if (! read_Bezier_polygon(filename2, P2)) {
    std::cerr << "Failed to read " << filename2 << " ..." << std::endl;
    return -1;
  }
  double secs = timer.elapsed();
  std::cout << "Constructed the input polygons in " << secs << " seconds."
            << std::endl;
  
  // Compute the intersection of the two polygons.
  Polygon_set R;
  timer.restart();
  CGAL::intersection(P1, P2, std::back_inserter(R));
  secs = timer.elapsed();
  
  std::cout << "The intersection polygons are of sizes: {";
  for (Polygon_set::const_iterator rit = R.begin(); rit != R.end(); ++rit)
    std::cout << ' ' << rit->outer_boundary().size();
  std::cout << " }" << std::endl;
  std::cout << "The intersection computation took " << secs << " seconds."
            << std::endl;
  return 0;
}
