#ifndef BOPS_SET_LINEAR_H
#define BOPS_SET_LINEAR_H

#include "bops_linear.h"

#include <CGAL/Polygon_set_2.h>

typedef CGAL::Polygon_set_2<Kernel>             Polygon_set;

#endif
