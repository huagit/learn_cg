// File: ex_connect_holes.cpp

#include <iostream>
#include <list>

#include "bops_linear.h"
#include "read_objects.h"

#include <CGAL/connect_holes.h>

int main(int argc, char* argv[])
{
  // Read a polygon with holes.
  const char* filename = (argc > 1) ? argv[1] : "polygon_with_holes.dat";
  std::ifstream  is;
  if (!open_stream(is, filename)) return -1;
  Polygon_with_holes P;
  is >> P;

  // Connect the outer boundary of the polygon with its holes.
  std::list<Point> pts;
  CGAL::connect_holes(P, std::back_inserter(pts));
  std::copy(pts.begin(), pts.end(),
            std::ostream_iterator<Point>(std::cout, "\n"));
  return 0;
}
