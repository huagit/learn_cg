// File: ex_simple_join_intersect.cpp

#include "bops_linear.h"
#include "pgn_print.h"

int main()
{
  // Construct the two input polygons.
  Polygon   P;
  P.push_back(Point(0, 0));        P.push_back(Point(9, 0));
  P.push_back(Point(9, 2));        P.push_back(Point(7, 4));
  P.push_back(Point(4.5, 1.5));    P.push_back(Point(2, 4));
  P.push_back(Point(0, 2));
  std::cout << "P = ";   print_polygon(P);

  Polygon   Q;
  Q.push_back(Point(0, 6));        Q.push_back(Point(0, 4));
  Q.push_back(Point(2, 2));        Q.push_back(Point(4.5, 4.5));
  Q.push_back(Point(7, 2));        Q.push_back(Point(9, 4));
  Q.push_back(Point(9, 6));
  std::cout << "Q = ";   print_polygon(Q);

  // Compute the union of P and Q.
  Polygon_with_holes   unionR;
  if (CGAL::join(P, Q, unionR)) {
    std::cout << "The union: ";
    print_polygon_with_holes(unionR);
  }
  else
    std::cout << "P and Q are disjoint and their union is trivial." << std::endl;
  std::cout << std::endl;

  // Compute the intersection of P and Q.
  Pgn_with_holes_container                  intersectionR;
  CGAL::intersection(P, Q, std::back_inserter(intersectionR));
  Pgn_with_holes_container::const_iterator  it;
  std::cout << "The intersection:" << std::endl;
  for (it = intersectionR.begin(); it != intersectionR.end(); ++it) {
    std::cout << "--> ";
    print_polygon_with_holes(*it);
  }
  return 0;
}
