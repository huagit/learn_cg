#ifndef READ_POLYGONS_H
#define READ_POLYGONS_H

#include <fstream>
#include <vector>
#include <list>

#include <CGAL/basic.h>

#include "numerical_cast.h"
#include "read_objects.h"

// Convert a double-precision value to a rational number.
template <typename Number_type> Number_type to_rational(const double& val)
{
  // Assume there are at most 6 decimal digits after the decimal point.
  return numerical_cast<Number_type, 1000000>(val);
}

// Read a set of input polygons from the given input stream.
template <typename Traits, typename Output_iterator>
Output_iterator read_polygons(const char* filename, Output_iterator oi,
                              Traits& traits)
{
  std::ifstream is;
  if (! open_stream(is, filename)) return oi;

  typedef typename Traits::NT                         NT;
  typedef typename Traits::Rational_point_2           Rational_point;
  typedef typename Traits::Rational_circle_2          Circle;
  typedef typename Traits::Point_2                    Point;
  typedef typename Traits::X_monotone_curve_2         X_monotone_curve;
  typedef typename Traits::Curve_2                    Curve;
  
  // Read the polygons one by one.
  typename Traits::Make_x_monotone_2 mk_x_monotone =
    traits.make_x_monotone_2_object();
  X_monotone_curve  xcv;
  
  char  ctype;
  while (is >> ctype) {
    // Read the polygon according to its type: 'p' (polygon) or 'c' (circle).
    typename Traits::Polygon_2 pgn;
    if (ctype == 'c' || ctype == 'C') {
      // Read a circle, given by its center (x, y) and its radius r.
      double  dx, dy, dr;
      is >> dx >> dy >> dr;
      const NT  x0 = to_rational<NT>(dx);
      const NT  y0 = to_rational<NT>(dy);
      const NT  rad = to_rational<NT>(dr);

      // Break the circle into two x-monotone arcs.
      std::list<CGAL::Object>  objects;
      mk_x_monotone(Curve(Rational_point(x0, y0), rad),
                    std::back_inserter(objects));
      CGAL_assertion(objects.size() == 2);
      std::list<CGAL::Object>::iterator  it = objects.begin();
      CGAL::assign(xcv, *it++);    pgn.push_back(xcv);
      CGAL::assign(xcv, *it);      pgn.push_back(xcv);
    }
    else if (ctype == 'p' || ctype == 'P') {
      // Read the number of vertices in the generalized polygon, then read
      // all points and bulge values.
      unsigned int  n;
      is >> n;

      std::vector<std::pair<std::pair<double, double>, double> >  verts(n);
      for (unsigned int i = 0; i < n; ++i) {
        double  dx, dy, dbulge;
        is >> dx >> dy >> dbulge;
        verts[i] = std::make_pair(std::make_pair(dx, dy), dbulge);
      }

      // Now compute the polygon edges.
      for (unsigned int i = 0; i < n; ++i) {
        const NT  x1 = to_rational<NT>(verts[i].first.first);
        const NT  y1 = to_rational<NT>(verts[i].first.second);
        const NT  x2 = to_rational<NT>(verts[(i + 1) % n].first.first);
        const NT  y2 = to_rational<NT>(verts[(i + 1) % n].first.second);
        const NT  bulge = to_rational<NT>(verts[i].second);
        const CGAL::Sign   sign_bulge = CGAL::sign(bulge);

        if (sign_bulge == CGAL::ZERO) {
          // Zero bulge value: the current edge is a line segment.
          if (CGAL::compare(x1, x2) != CGAL::EQUAL ||
              CGAL::compare(y1, y2) != CGAL::EQUAL)
            pgn.push_back(X_monotone_curve(Rational_point(x1,y1),
                                           Rational_point(x2,y2)));
        }
        else {
          // A non-zero bulge: ps and pt are connected by a circular arc.
          // Compute the center and the squared radius of its supporting circle.
          CGAL_assertion((CGAL::compare(x1, x2) != CGAL::EQUAL) ||
                         (CGAL::compare(y1, y2) != CGAL::EQUAL));

          const NT common = (1 - CGAL::square(bulge)) / (4*bulge);
          const NT x0 = (x1 + x2)/2 + common*(y1 - y2);
          const NT y0 = (y1 + y2)/2 + common*(x2 - x1);
          const NT sqr_bulge = CGAL::square(bulge);
          const NT sqr_dist = CGAL::square(x2 - x1) + CGAL::square(y2 - y1);
          const NT sqr_radius = sqr_dist * (1/sqr_bulge + 2 + sqr_bulge) / 16;

          // Construct the arc: A positive (resp. negative) bulge implies a
          // counterclockwise- (resp. clockwise-) oriented arc.
          Circle supp_circ = (sign_bulge == CGAL::POSITIVE) ?
            Circle(Rational_point(x0, y0), sqr_radius,
                   CGAL::COUNTERCLOCKWISE) :
            Circle(Rational_point(x0, y0), sqr_radius, CGAL::CLOCKWISE);

          Curve circ_arc(supp_circ, Point(x1, y1), Point(x2, y2));

          // Break the arc into x-monotone subarcs (there can be at most
          // three subarcs) and add them to the polygon.
          std::list<CGAL::Object>  objects;
          mk_x_monotone(circ_arc, std::back_inserter(objects));
          CGAL_assertion(objects.size() <= 3);
          std::list<CGAL::Object>::iterator  it = objects.begin();
          for (it = objects.begin(); it != objects.end(); ++it)
            if (CGAL::assign (xcv, *it)) pgn.push_back (xcv);
        }
      }
    }
    else CGAL_error();          // illegal type

    *oi++ = pgn;                // write the polygon to the output iterator.
  }
  close_stream(is);
  return oi;
}

#endif
