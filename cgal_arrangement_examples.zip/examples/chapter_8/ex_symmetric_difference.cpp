// File: ex_symmetric_difference.cpp

#include "bops_linear.h"
#include "pgn_print.h"

int main()
{
  // Construct P - a bounded rectangle that contains a rectangular hole.
  Polygon  outP, holesP;
  outP.push_back(Point(-3, -5));       outP.push_back(Point(3, -5));
  outP.push_back(Point(3, 5));         outP.push_back(Point(-3, 5));
  holesP.push_back(Point(-1, -3));     holesP.push_back(Point(-1, 3));
  holesP.push_back(Point(1, 3));       holesP.push_back(Point(1, -3));
  Polygon_with_holes  P(outP, &holesP, &holesP + 1); 
  std::cout << "P = "; print_polygon_with_holes(P);

  // Construct Q - a bounded rectangle that contains a rectangular hole.
  Polygon  outQ, holesQ;
  outQ.push_back(Point(-5, -3));       outQ.push_back(Point(5, -3));
  outQ.push_back(Point(5, 3));         outQ.push_back(Point(-5, 3));
  holesQ.push_back(Point(-3, -1));     holesQ.push_back(Point(-3, 1));
  holesQ.push_back(Point(3, 1));       holesQ.push_back(Point(3, -1));
  Polygon_with_holes  Q(outQ, &holesQ, &holesQ + 1);
  std::cout << "Q = "; print_polygon_with_holes(Q);

  // Compute the symmetric difference of P and Q.
  Pgn_with_holes_container                  symmR;
  CGAL::symmetric_difference(P, Q, std::back_inserter(symmR));
  std::cout << "The symmetric difference:" << std::endl;
  Pgn_with_holes_container::const_iterator  it;
  for (it = symmR.begin(); it != symmR.end(); ++it) {
    std::cout << "--> "; 
    print_polygon_with_holes(*it);
  }
  return 0;
}
