// File: ex_sequence.cpp

#include "bops_set_linear.h"
#include "pgn_print.h"

int main()
{
  // Construct the two initial polygons and the clipping rectangle.
  Polygon      P, Q, R;

  P.push_back(Point(2, 4));        P.push_back(Point(7, 2));
  P.push_back(Point(4, 4));        P.push_back(Point(7, 6));

  Q.push_back(Point(4, 2));        Q.push_back(Point(9, 4));
  Q.push_back(Point(4, 6));        Q.push_back(Point(7, 4));

  R.push_back(Point(1, 1));        R.push_back(Point(10, 1));
  R.push_back(Point(10, 7));       R.push_back(Point(1, 7));
  
  // Perform a sequence of set operations and print the result.
  Polygon_set  S;
  S.insert(P);
  S.join(Q);                 // Compute the union of P and Q.
  S.complement();            // Compute the complement.
  S.intersection(R);         // Intersect with the clipping rectangle.
  print_polygon_set(S);
  return 0;
}
