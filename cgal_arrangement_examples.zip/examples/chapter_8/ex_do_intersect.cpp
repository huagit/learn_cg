// File: ex_do_intersect.cpp

#include <CGAL/basic.h>
#include <CGAL/Exact_predicates_exact_constructions_kernel.h>
#include <CGAL/Boolean_set_operations_2.h>

#include "pgn_print.h"

typedef CGAL::Exact_predicates_exact_constructions_kernel  Kernel;
typedef Kernel::Point_2                                    Point;
typedef CGAL::Polygon_2<Kernel>                            Polygon;

int main()
{
  // Constuct two triangular polygons and check whether they intersect.
  Polygon T1;
  T1.push_back(Point(1, 1));  T1.push_back(Point(4, 1));
  T1.push_back(Point(1, 3));
  std::cout << "T1 = ";   print_polygon(T1);

  Polygon T2;
  T2.push_back(Point(2, 2));  T2.push_back(Point(5, 1));
  T2.push_back(Point(4, 3));
  std::cout << "T2 = ";   print_polygon(T2);

  std::cout << (CGAL::do_intersect(T1, T2) ?
                "The two polygons intersect in their interior." :
                "The two polygons do not intersect.") << std::endl;
  return 0;
}
