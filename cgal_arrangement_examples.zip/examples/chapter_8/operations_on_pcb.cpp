// File: operation_on_ccb.cpp

#include <list>
#include <boost/timer.hpp>

#include <CGAL/basic.h>
#include <CGAL/IO/Gps_iostream.h>

#include "bops_circular.h"
#include "read_polygons.h"
#include "polygon_orientation.h"

int main(int argc, char* argv[])
{
  // Read the circular polygons from the input file.
  const char* filename = (argc >= 2) ? argv[1] : "vlsi.dat";
  std::list<Polygon>      pgns;
  Traits traits;
  std::cout << "Reading <" << filename << "> ... " << std::flush;
  boost::timer  timer;
  read_polygons(filename, std::back_inserter(pgns), traits);
  double secs = timer.elapsed();
  std::cout << "Read " << pgns.size() << " polygons (" << secs << " seconds)."
            << std::endl;

  // Repair polygon orientation.
  std::list<Polygon>::iterator it;
  for (it = pgns.begin(); it != pgns.end(); ++it) {
    if (CGAL::CLOCKWISE ==
        polygon_orientation(it->curves_begin(), it->curves_end(), traits))
      it->reverse_orientation();
  }

  // Compute the union of the polygons.
  Polygon_set S(traits);
  std::cout << "Computing the union ... " << std::flush;
  timer.restart();
  S.join(pgns.begin(), pgns.end());
  secs = timer.elapsed();
  std::cout << "Done! (" << secs << " seconds)." << std::endl;

  return 0;
}
