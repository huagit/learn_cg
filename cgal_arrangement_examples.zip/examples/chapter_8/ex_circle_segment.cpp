// File: ex_circle_segment.cpp

#include <list>
#include <iostream>

#include <CGAL/IO/Gps_iostream.h>

#include "bops_circular.h"

typedef Traits::Rational_point_2                        Point;
typedef Traits::Rational_circle_2                       Circle;

// Construct a polygon from a circle.
Polygon ctr_polygon(const Circle& circle)
{
  // Subdivide the circle into two x-monotone arcs.
  Traits traits;
  Traits::Curve_2 curve(circle);  // circle orientation is counterclockwise
  std::list<CGAL::Object>  objects;
  traits.make_x_monotone_2_object()(curve, std::back_inserter(objects));
  CGAL_assertion(objects.size() == 2);

  // Construct a polygon that comprises the two x-monotone arcs.
  Polygon                            polygon;
  std::list<CGAL::Object>::iterator  it = objects.begin();
  Traits::X_monotone_curve_2         arc;
  CGAL::assign(arc, *it++);  polygon.push_back(arc);
  CGAL::assign(arc, *it);    polygon.push_back(arc);
  return polygon;
}

// Construct a quadrilateral polygon.
Polygon ctr_polygon(const Point& p1, const Point& p2,
                    const Point& p3, const Point& p4)
{
  Polygon           polygon;
  polygon.push_back(Traits::X_monotone_curve_2(p1, p2));
  polygon.push_back(Traits::X_monotone_curve_2(p2, p3));
  polygon.push_back(Traits::X_monotone_curve_2(p3, p4));
  polygon.push_back(Traits::X_monotone_curve_2(p4, p1));
  return polygon;
}

// The main program:
int main()
{
  // Insert four non-intersecting circles.
  Polygon_set  S;
  S.insert(ctr_polygon(Circle(Point(1, 1), 1)));      // C1
  S.insert(ctr_polygon(Circle(Point(5, 1), 1)));      // C2
  S.insert(ctr_polygon(Circle(Point(5, 5), 1)));      // C3
  S.insert(ctr_polygon(Circle(Point(1, 5), 1)));      // C4

  // Compute the union with four rectangles.
  S.join(ctr_polygon(Point(1, 0), Point(5, 0), Point(5, 2), Point(1, 2)));
  S.join(ctr_polygon(Point(1, 4), Point(5, 4), Point(5, 6), Point(1, 6)));
  S.join(ctr_polygon(Point(0, 1), Point(2, 1), Point(2, 5), Point(0, 5)));
  S.join(ctr_polygon(Point(4, 1), Point(6, 1), Point(6, 5), Point(4, 5)));

  std::cout << S;
  return 0;
}
