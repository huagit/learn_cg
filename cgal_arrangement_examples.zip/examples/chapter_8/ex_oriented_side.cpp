// File: ex_oriented_side.cpp

#include "bops_linear.h"
#include "pgn_print.h"

template <typename Obj1, typename Obj2>
void print_oriented_side(const Obj1& obj1, const Obj2& obj2)
{
  CGAL::Oriented_side os = CGAL::oriented_side(obj1, obj2);
  std::cout << "(" << obj1 << ")"
            << ((os == CGAL::ON_POSITIVE_SIDE) ? " inside " :
                ((os == CGAL::ON_NEGATIVE_SIDE) ? " outside " : " on boundary "))
            << "(" << obj2 << ")" << std::endl;
}

int main()
{
  // Define a square polygon P and its complement Q.
  Polygon P;
  P.push_back(Point(-1, -1));       P.push_back(Point(1, -1));
  P.push_back(Point(1, 1));         P.push_back(Point(-1, 1));

  Polygon_with_holes Q;
  complement(P, Q);

  // Define the query points p1 located in P and p2 located on the boundary of P.
  Point p1(0, 0), p2(1, 1);

  print_oriented_side(p1, P);
  print_oriented_side(p2, P);
  print_oriented_side(p1, Q);
  print_oriented_side(p2, Q);
  print_oriented_side(P, Q);
  return 0;
}
