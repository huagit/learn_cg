#ifndef DUAL_PLANE_H
#define DUAL_PLANE_H

template <typename Traits> typename Traits::Point_2
primal_point(const typename Traits::X_monotone_curve_2& cv)
{
  // If the supporting dual line of the linear curve is a*x + b*y + c = 0,
  // the primal point is (-a/b, c/b).
  const typename Traits::Line_2&  line = cv.supporting_line();
  CGAL_assertion(CGAL::sign(line.b()) != CGAL::ZERO);
  return typename Traits::Point_2(-line.a() / line.b(), line.c() / line.b());
}

template <typename Traits> typename Traits::X_monotone_curve_2
dual_line(const typename Traits::Point_2& p)
{
  // The line dual to the point (p_x, p_y) is y = p_x*x - p_y
  // (or p_x*x - y - p_y = 0).
  typename Traits::Line_2 line(p.x(), -1, -p.y());
  return typename Traits::X_monotone_curve_2(line);
}

#endif
