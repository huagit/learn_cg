// File: min_area_triangle.cpp

#include <CGAL/basic.h>

#include "arr_linear.h"
#include "arr_print.h"
#include "read_objects.h"
#include "is_in_x_range.h"
#include "dual_plane.h"
#include "find_parallel_lines.h"

typedef Arrangement::Halfedge_around_vertex_const_circulator
  Halfedge_around_vertex_const_circulator;

int main(int argc, char* argv[])
{
  // Get the name of the input file from the command line, or use the default
  // points.dat file if no command-line parameters are given.
  const char* filename = (argc > 1) ? argv[1] : "points.dat";
  std::list<Point> points;
  read_objects<Point>(filename, std::back_inserter(points));

  std::list<X_monotone_curve>  dual_lines;
  std::list<Point>::const_iterator it;
  for (it = points.begin(); it != points.end(); ++it)
    dual_lines.push_back(dual_line<Traits>(*it));
  
  // Aggregately construct the arrangement of dual lines.
  Traits traits;
  Arrangement arr(&traits);
  insert(arr, dual_lines.begin(), dual_lines.end());
  print_unbounded_arrangement_size(arr);

  // Detect 3 parallel lines, as they are the dual of 3 primal collinear points.
  X_monotone_curve cv1, cv2, cv3;
  Kernel                                 ker;
  if (find_parallel_lines(arr, cv1, cv2, cv3, ker)) {
      std::cout << "The minimum-area triangle is "
                << "(" << primal_point<Traits>(cv1) << ")"
                << "(" << primal_point<Traits>(cv2) << ")"
                << "(" << primal_point<Traits>(cv3) << ")"
                << ", with area = 0" << std::endl;
      return 0;
  }
  
  // Go over all arrangement vertices and look for the vertex (intersection
  // of two lines) and the halfedge that induce the minimum-area triangle.
  Kernel::Compute_area_2  area = ker.compute_area_2_object(); 
  Point                   min_p1, min_p2, min_p3;
  Number_type             min_area;
  bool                    found = false;

  Arrangement::Vertex_const_iterator   vit;
  for (vit = arr.vertices_begin(); vit != arr.vertices_end(); ++vit) {
    // Each vertex is incident to at least 2 dual lines; get their dual points.
    Halfedge_around_vertex_const_circulator  circ = vit->incident_halfedges();
    Point p1 = primal_point<Traits>(circ++->curve());
    Point p2 = primal_point<Traits>(circ->curve());
    
    // If the vertex degree is greater than 4, it is incident to three lines,
    // whose primal points are collinear.
    if (vit->degree() > 4) {
      std::cout << "The minimum-area triangle is (" << p1 << ") (" << p2
                << ") (" << primal_point<Traits>((++circ)->curve())
                << "), with area = 0" << std::endl;
      return 0;
    }

    // Locate the halfedges that lie above and below the vertex. 
    Halfedge_around_vertex_const_circulator  first;
    circ = first = vit->incident_halfedges();
    do {
      // Check whether the current halfedge is incident to a face that lies
      // above (or below) the current vertex. If so, look for a non-fictitious
      // halfedge along the face boundary that lies above (or below) the vertex.
      if (circ->direction() == circ->next()->direction()) {
        // The halfedge circ and its next halfedge are incident to the current
        // vertex, so there is no need to check them.
        Arrangement::Halfedge_const_handle  he;
        for (he = circ->next()->next(); he != circ; he = he->next()) {
          if (he->is_fictitious() ||            // skip ficititious edges
              !is_in_x_range<Arrangement>(he, vit->point(), traits))
            continue;

          // Compute the area induced by the three points and compare it
          // to the minimal area so far.
          Point p3 = primal_point<Traits>(he->curve());
          Number_type curr_area = CGAL::abs(area(p1, p2, p3));
          if (!found || CGAL::compare(curr_area, min_area) == CGAL::SMALLER) {
            min_p1 = p1;
            min_p2 = p2;
            min_p3 = p3;
            min_area = curr_area;
            found = true;
          }
          break;
        }
      }
    } while (++circ != first);
  } // End loop on the arrangement vertices.

  CGAL_assertion(found);
  std::cout << "The minimum-area triangle is (" << min_p1 << ") (" << min_p2
            << ") (" << min_p3 << "), with area = " << min_area << std::endl;
  return 0;
}
