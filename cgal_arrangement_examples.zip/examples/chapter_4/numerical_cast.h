#ifndef NUMERICAL_CAST_H
#define NUMERICAL_CAST_H

#include <CGAL/Exact_predicates_exact_constructions_kernel.h>
#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>

// Convert a double-precision value to a rational number.
template <int denom>
CGAL::Gmpq numerical_cast_imp(const double& val, CGAL::Gmpq)
{ return CGAL::Gmpq(static_cast<int>(val*denom + 0.5), denom); }

template <int denom>
CGAL::Exact_predicates_exact_constructions_kernel::FT
numerical_cast_imp(const double& val,
                   CGAL::Exact_predicates_exact_constructions_kernel::FT)
{
  CGAL::Gmpq tmp = numerical_cast_imp<denom>(val, CGAL::Gmpq());
  return CGAL::Exact_predicates_exact_constructions_kernel::FT(tmp);
}

template <int denom>
CGAL::Exact_predicates_inexact_constructions_kernel::FT
numerical_cast_imp(const double& val,
                   CGAL::Exact_predicates_inexact_constructions_kernel::FT)
{ return val; }

template <typename Target, int denom, typename Source>
Target numerical_cast(const Source& val)
{ return numerical_cast_imp<denom>(val, Target()); }

#endif
