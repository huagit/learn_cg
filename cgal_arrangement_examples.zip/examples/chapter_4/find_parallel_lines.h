#ifndef FIND_PARALLEL_LINES_H
#define FIND_PARALLEL_LINES_H

template <typename Arrangement, typename Kernel>
bool find_parallel_lines(const Arrangement& arr,
                         typename Arrangement::X_monotone_curve_2& cv1,
                         typename Arrangement::X_monotone_curve_2& cv2,
                         typename Arrangement::X_monotone_curve_2& cv3,
                         Kernel& kernel)
{
  typename Kernel::Are_parallel_2 are_parallel =
    kernel.are_parallel_2_object();
  typename Arrangement::Face_const_handle uf = arr.fictitious_face();
  typename Arrangement::Hole_const_iterator hit = uf->holes_begin();
  typename Arrangement::Ccb_halfedge_const_circulator first = *hit;
  typename Arrangement::Ccb_halfedge_const_circulator next = first;
  do {
    typename Arrangement::Ccb_halfedge_const_circulator curr = next++;
    if ((curr->source()->degree() == 2) || (curr->target()->degree() == 2) ||
        (next->target()->degree() == 2))
      continue;

    CGAL::Arr_parameter_space ps1 = curr->source()->parameter_space_in_x();
    CGAL::Arr_parameter_space ps2 = curr->target()->parameter_space_in_x();
    CGAL::Arr_parameter_space ps3 = next->target()->parameter_space_in_x();
    if ((ps1 != ps2) || (ps2 != ps3)) continue;

    cv1 = next->twin()->prev()->curve();
    cv2 = next->twin()->next()->curve();
    cv3 = curr->twin()->next()->curve();    
    if (are_parallel(cv1.supporting_line(),cv2.supporting_line()) &&
        are_parallel(cv2.supporting_line(),cv3.supporting_line()))
      return true;
  } while (next != first);

  return false;
}

#endif
