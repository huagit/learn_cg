#ifndef PRINT_DIAGRAM_H
#define PRINT_DIAGRAM_H

#include <boost/iterator/transform_iterator.hpp>

using boost::make_transform_iterator;

// Obtain the data attached to a surface by a traits decorator.
template <typename Surface>
const char& data(const Surface& surface) { return surface.data(); }

template <typename Diagram>
void print_diagram(const Diagram& diag)
{
  typedef typename Diagram::Xy_monotone_surface_3       Surf;
  
  // Go over all arrangement faces.
  typename Diagram::Face_const_iterator fit;
  for (fit = diag.faces_begin(); fit != diag.faces_end(); ++fit) {
    // Print the face boundary.
    if (fit->is_unbounded()) std::cout << "[Unbounded face]";
    else {
      // Print the vertices along the outer boundary of the face.
      std::cout << "[Face]  ";
      typename Diagram::Ccb_halfedge_const_circulator ccb = fit->outer_ccb();
      do std::cout << '(' << ccb->target()->point() << ")  ";
      while (++ccb != fit->outer_ccb());
    }
    
    // Print the labels of the surfaces that induce the envelope on this face.
    std::cout << "-->  " << fit->number_of_surfaces() << " surface(s): ";
    std::copy(make_transform_iterator(fit->surfaces_begin(), &data<Surf>),
              make_transform_iterator(fit->surfaces_end(), &data<Surf>),
              std::ostream_iterator<char>(std::cout, ", "));
    std::cout << std::endl;
  }

  // Go over all arrangement edges.
  typename Diagram::Edge_const_iterator eit;
  for (eit = diag.edges_begin(); eit != diag.edges_end(); ++eit) {
    // Print the labels of the surfaces that induce the envelope on this edge.
    std::cout << "[Edge]  (" << eit->source()->point() << ")  ("
              << eit->target()->point() << ")  -->  "
              << eit->number_of_surfaces() << " surface(s): ";
    std::copy(make_transform_iterator(eit->surfaces_begin(), &data<Surf>),
              make_transform_iterator(eit->surfaces_end(), &data<Surf>),
              std::ostream_iterator<char>(std::cout, ", "));
    std::cout << std::endl;
  }

  // Go over all arrangement vertices.
  typename Diagram::Vertex_const_iterator vit;
  for (vit = diag.vertices_begin(); vit != diag.vertices_end(); ++vit) {
    // Print the labels of the surfaces that induce the envelope on the vertex.
    std::cout << "[Vertex]  (" << vit->point() << ")  -->  "
              << vit->number_of_surfaces() << " surface(s): ";
    std::copy(make_transform_iterator(vit->surfaces_begin(), &data<Surf>),
              make_transform_iterator(vit->surfaces_end(), &data<Surf>),
              std::ostream_iterator<char>(std::cout, ", "));
    std::cout << std::endl;
  }  
}

#endif
