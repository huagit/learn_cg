// File: ex_convex_hull.cpp

#include <vector>

#include <CGAL/basic.h>
#include <CGAL/Arr_curve_data_traits_2.h>
#include <CGAL/Envelope_diagram_1.h>
#include <CGAL/envelope_2.h>

#include "arr_linear.h"
#include "read_objects.h"
#include "dual_plane.h"

typedef CGAL::Arr_curve_data_traits_2<Traits, unsigned int>   Data_traits; 
typedef Data_traits::X_monotone_curve_2                       Dual_line;
typedef CGAL::Envelope_diagram_1<Data_traits>                 Diagram;

using CGAL::lower_envelope_x_monotone_2;
using CGAL::upper_envelope_x_monotone_2;

int main(int argc, char* argv[])
{
  // Read the points from the input file.
  const char * filename = (argc > 1) ? argv[1] : "ch_points.dat";
  std::vector<Point>    points;
  read_objects<Point>(filename, std::back_inserter(points));

  // Consturct the lines dual to the points.
  std::list<Dual_line>  dual_lines;
  std::vector<Point>::const_iterator it;
  unsigned int            k = 0;
  for (it = points.begin(); it != points.end(); ++it) {
    dual_lines.push_back(Dual_line(dual_line<Traits>(*it), k++));
  }
  
  // Compute the lower envelope of dual lines, which corresponds to the upper
  // part of the convex hull, and their upper envelope, which corresponds to
  // the lower part of the convex hull.
  Diagram              min_diag, max_diag;
  lower_envelope_x_monotone_2(dual_lines.begin(), dual_lines.end(), min_diag);
  upper_envelope_x_monotone_2(dual_lines.begin(), dual_lines.end(), max_diag);

  // Output the points along the boundary convex hull in a counterclockwise
  // order. We start by traversing the minimization diagram from right to
  // left, and then traverse the maximization diagram from left to right.
  std::cout << "The convex hull of " << points.size() << " input points:";
  Diagram::Edge_const_handle  e = min_diag.leftmost();
  while (e != min_diag.rightmost()) {
    std::cout << " (" << points[e->curve().data()] << ')';
    e = e->right()->right();
  }
  // Handle the degenerate case of a vertical convex hull edge.
  if (e->curve().data() != max_diag.leftmost()->curve().data())
    std::cout << " (" << points[e->curve().data()] << ')';

  e = max_diag.leftmost();
  while (e != max_diag.rightmost()) {
    std::cout << " (" << points[e->curve().data()] << ')';
    e = e->right()->right();
  }
  // Handle the degenerate case of a vertical convex hull edge.
  if (e->curve().data() != min_diag.leftmost()->curve().data())
    std::cout << " (" << points[e->curve().data()] << ')';

  std::cout << std::endl;
  return 0;
}
