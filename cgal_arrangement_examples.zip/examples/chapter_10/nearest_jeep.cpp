// File: nearest_jeep.cpp

#include <list>
#include <vector>
#include <iostream>
#include <boost/lexical_cast.hpp>
#include <boost/tuple/tuple.hpp>
#include <boost/tuple/tuple_io.hpp>

#include <CGAL/basic.h>
#include <CGAL/Arr_curve_data_traits_2.h>
#include <CGAL/Envelope_diagram_1.h>
#include <CGAL/envelope_2.h>

#include "arr_rat_functions.h"
#include "read_objects.h"

typedef CGAL::Arr_curve_data_traits_2<Traits, unsigned int> Data_traits; 
typedef Data_traits::Curve_2                                Indexed_curve;
typedef CGAL::Envelope_diagram_1<Data_traits>               Diagram;
typedef boost::tuple<int, int, int, int>                    Jeep;

int main(int argc, char* argv[])
{
  if (argc < 4) {
    std::cerr << "Usage: " << argv[0] << " <input file> <x_0> <y_0>"
              << std::endl;
    return -1;
  }

  // Define a traits class object and a constructor for rational functions. 
  Traits traits;
  Traits::Construct_curve_2 construct = traits.construct_curve_2_object(); 

  // Analyze the command line and obtain the name of the input file
  // and the location of the base station b = (x_0, y_0).
  const char*   filename = argv[1];
  const Traits::Rational  x_0(boost::lexical_cast<int>(argv[2]));
  const Traits::Rational  y_0(boost::lexical_cast<int>(argv[3]));

  // Read the jeeps from the file, and construct the parabolic arcs
  // representing the functions of their squared distance from the base b.
  std::vector<Jeep> jeeps;
  read_objects<Jeep>(filename, std::back_inserter(jeeps));
  std::list<Indexed_curve>     arcs;
  std::vector<Jeep>::const_iterator it;
  unsigned int k = 0;
  for (it = jeeps.begin(); it != jeeps.end(); ++it) {
    Traits::Rational p_x = Traits::Rational(boost::get<0>(*it));
    Traits::Rational p_y = Traits::Rational(boost::get<1>(*it));
    Traits::Rational v_x = Traits::Rational(boost::get<2>(*it));
    Traits::Rational v_y = Traits::Rational(boost::get<3>(*it));

    // Construct the parabolic arc whose supporting conic is
    // alpha*x^2 + beta*x - y + gamma = 0.
    // Note that we also associate the parabolic arc with its jeep index.
    std::vector<Traits::Rational> coefficients(3);
    coefficients[2] = CGAL::square(v_x) + CGAL::square(v_y);
    coefficients[1] = 2*((p_x - x_0)*v_x + (p_y - y_0)*v_y);
    coefficients[0] = CGAL::square(p_x - x_0) + CGAL::square(p_y - y_0);

    // Construct an arc over the interval [0, infinity).
    Traits::Curve_2 arc = construct(coefficients.begin(), coefficients.end(),
                                    Alg_real(0), true);
    arcs.push_back(Indexed_curve(arc, k++));
  }

  // Compute the minimization diagram that represents the lower envelope
  // of the parabolic arcs.
  Diagram  min_diag;
  CGAL::lower_envelope_2(arcs.begin(), arcs.end(), min_diag);

  // Every left bounded edge in the diagram represents a time interval over
  // which the identity of the nearest jeep does not change. Print these
  // time intervals and the index of the nearest jeep for each interval. 
  Diagram::Edge_const_handle     e = min_diag.leftmost()->right()->right();
  while (e != min_diag.rightmost()) {
    CGAL_assertion(! e->is_empty());
    std::cout << "From time " << CGAL::to_double(e->left()->point().x())
              << " to time " << CGAL::to_double(e->right()->point().x())
              << " the nearest jeep no. is " << e->curve().data() << '.'
              << std::endl;
    e = e->right()->right();
  }
  std::cout << "From time " << CGAL::to_double(e->left()->point().x())
            << " to infinity the nearest jeep no. is " << e->curve().data()
            << '.' << std::endl;
  return 0;
}
