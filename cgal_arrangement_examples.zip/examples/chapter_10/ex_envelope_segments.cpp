// File: ex_envelope_segments.cpp

#include <list>
#include <iostream>

#include <CGAL/basic.h>
#include <CGAL/Arr_curve_data_traits_2.h>
#include <CGAL/Envelope_diagram_1.h>
#include <CGAL/envelope_2.h>

#include "arr_exact_construction_segments.h"

typedef CGAL::Arr_curve_data_traits_2<Traits, char>   Data_traits; 
typedef Data_traits::X_monotone_curve_2               Label_seg;
typedef CGAL::Envelope_diagram_1<Data_traits>         Diagram;

int main()
{
  // Consrtuct the input segments and label them 'A' ... 'H'.
  std::list<Label_seg>  segs;
  segs.push_back(Label_seg(Segment(Point(0, 1), Point(2, 3)), 'A'));
  segs.push_back(Label_seg(Segment(Point(1, 2), Point(4, 5)), 'B'));
  segs.push_back(Label_seg(Segment(Point(1, 5), Point(7, 2)), 'C'));
  segs.push_back(Label_seg(Segment(Point(4, 2), Point(6, 4)), 'D'));
  segs.push_back(Label_seg(Segment(Point(8, 3), Point(8, 6)), 'E'));
  segs.push_back(Label_seg(Segment(Point(9, 2), Point(12, 4)), 'F'));
  segs.push_back(Label_seg(Segment(Point(10, 2), Point(12, 1)), 'G'));
  segs.push_back(Label_seg(Segment(Point(11, 0), Point(11, 5)), 'H'));

  // Compute the minimization diagram that represents their lower envelope.
  Diagram  min_diag;
  CGAL::lower_envelope_x_monotone_2(segs.begin(), segs.end(), min_diag);

  // Print the minimization diagram.
  Diagram::Edge_const_handle     e = min_diag.leftmost();
  while (e != min_diag.rightmost()) {
    Diagram::Curve_const_iterator  cit;
    std::cout << "Edge:";
    if (! e->is_empty())
      for (cit = e->curves_begin(); cit != e->curves_end(); ++cit)
        std::cout << ' ' << cit->data();
    else std::cout << " [empty]";
    std::cout << std::endl;

    Diagram::Vertex_const_handle v = e->right();
    std::cout << "Vertex(" << v->point() << "): ";
    for (cit = v->curves_begin(); cit != v->curves_end(); ++cit)
      std::cout << ' ' << cit->data();
    std::cout << std::endl;

    e = v->right();
  }
  CGAL_assertion(e->is_empty());
  std::cout << "Edge: [empty]" << std::endl;
  return 0;
}
