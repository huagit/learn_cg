// File: ex_envelope_triangles.cpp

#include <iostream>
#include <list>

#include <CGAL/basic.h>
#include <CGAL/Env_triangle_traits_3.h>
#include <CGAL/Env_surface_data_traits_3.h>
#include <CGAL/envelope_3.h>

#include "arr_exact_construction_segments.h"
#include "print_diagram.h"

typedef CGAL::Env_triangle_traits_3<Kernel>              Traits_3;
typedef Kernel::Point_3                                  Point_3;
typedef Traits_3::Surface_3                              Triangle_3;
typedef CGAL::Env_surface_data_traits_3<Traits_3, char>  Data_traits;
typedef Data_traits::Surface_3                           Data_triangle;
typedef CGAL::Envelope_diagram_2<Data_traits>            Envelope_diagram;

int main()
{
  // Construct the input triangles, marked A and B.
  std::list<Data_triangle>   triangles;
  Triangle_3 ta(Point_3(0, 0, 0), Point_3(0, 6, 0), Point_3(5, 3, 4));
  Triangle_3 tb(Point_3(6, 0, 0), Point_3(6, 6, 0), Point_3(1, 3, 4));
  triangles.push_back(Data_triangle(ta, 'A'));
  triangles.push_back(Data_triangle(tb, 'B'));

  // Compute and print the minimization diagram.
  Envelope_diagram  min_diag;
  CGAL::lower_envelope_3(triangles.begin(), triangles.end(), min_diag);
  std::cout << std::endl << "The minimization diagram:" << std::endl;
  print_diagram(min_diag);

  // Compute and print the maximization diagram.
  Envelope_diagram  max_diag;
  CGAL::upper_envelope_3(triangles.begin(), triangles.end(), max_diag);
  std::cout << std::endl << "The maximization diagram:" << std::endl;
  print_diagram(max_diag);

  return 0;
}
