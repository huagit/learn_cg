// File: ex_envelope_spheres.cpp

#include <iostream>
#include <list>
#include <boost/timer.hpp>

#include <CGAL/basic.h>
#include <CGAL/Env_sphere_traits_3.h>
#include <CGAL/envelope_3.h>

#include "arr_print.h"
#include "arr_conics.h"
#include "read_objects.h"

typedef CGAL::Env_sphere_traits_3<Traits>             Traits_3;
typedef Traits_3::Surface_3                           Sphere;
typedef CGAL::Envelope_diagram_2<Traits_3>            Envelope_diagram;

int main(int argc, char* argv[])
{
  const char* filename = (argc > 1) ? argv[1] : "spheres.dat";
  std::list<Sphere>  spheres;
  read_objects<Sphere>(filename, std::back_inserter(spheres));
  Envelope_diagram   min_diag;
  std::cout << "Constructing the lower envelope of " << spheres.size()
            << " spheres." << std::endl;

  // Compute the envelope.
  boost::timer timer;
  CGAL::lower_envelope_3(spheres.begin(), spheres.end(), min_diag);
  double secs = timer.elapsed();

  // Print the minimization diagram.
  print_arrangement_size(min_diag);
  std::cout << "Construction took " << secs << " seconds." << std::endl;
  return 0;
}
