// File: farthest_point.cpp

#include <fstream>
#include <list>

#include <CGAL/basic.h>
#include <CGAL/Exact_predicates_exact_constructions_kernel.h>
#include <CGAL/Env_plane_traits_3.h>
#include <CGAL/Env_surface_data_traits_3.h>
#include <CGAL/envelope_3.h>
#include <CGAL/Arr_naive_point_location.h>

#include "read_objects.h"
#include "arr_print.h"

typedef CGAL::Exact_predicates_exact_constructions_kernel  Kernel;
typedef Kernel::FT                                         Number_type;
typedef Kernel::Point_2                                    Point;
typedef Kernel::Plane_3                                    Plane;
typedef CGAL::Env_plane_traits_3<Kernel>                   Traits;
typedef CGAL::Env_surface_data_traits_3<Traits, Point>     Data_traits;
typedef Data_traits::Surface_3                             Data_plane;
typedef CGAL::Envelope_diagram_2<Data_traits>              Envelope_diagram;
typedef CGAL::Arr_naive_point_location<Envelope_diagram>   Naive_pl;

int main(int argc, char* argv[])
{
  const char* filename1 = (argc > 1) ? argv[1] : "fp_points.dat";
  const char* filename2 = (argc > 2) ? argv[2] : "fp_queries.dat";
  std::list<Point> points;
  read_objects<Point>(filename1, std::back_inserter(points));

  std::list<Data_plane> planes;
  std::list<Point>::const_iterator it;
  for (it = points.begin(); it != points.end(); ++it) {
    // The surface induced by the point (p_x, p_y) is the plane:
    //  2*p_x*x + 2*p_y*y + z - (p_x^2 + p_y^2) = 0.
    Number_type px = it->x(), py = it->y();
    Plane plane(2*px, 2*py, 1, -(px*px + py*py));
    planes.push_back(Data_plane(plane, *it));
  }
  
  // Compute the maximization diagram of the planes.
  Envelope_diagram      max_diag;
  CGAL::upper_envelope_3(planes.begin(), planes.end(), max_diag);

  // Perform the queries.
  Naive_pl pl(max_diag);
  std::list<Point> queries;
  read_objects<Point>(filename2, std::back_inserter(queries));
  for (it = queries.begin(); it != queries.end(); ++it) {
    CGAL::Object obj = pl.locate(*it);

    // Print the query result according to the location of the query point.
    Envelope_diagram::Surface_const_iterator sit, sit_end;
    Envelope_diagram::Halfedge_const_handle  he;
    Envelope_diagram::Face_const_handle      f;
    Envelope_diagram::Vertex_const_handle    v;
    if (CGAL::assign(f, obj)) {
      sit = f->surfaces_begin();
      sit_end = f->surfaces_end();
    }
    else if (CGAL::assign(he, obj)) {
      sit = he->surfaces_begin();
      sit_end = he->surfaces_end();
    }
    else if (CGAL::assign(v, obj)) {
      sit = v->surfaces_begin();
      sit_end = v->surfaces_end();
    }
    else CGAL_error();

    std::cout << "The farthest point(s) from (" << *it << "):";
    while (sit != sit_end) std::cout << " (" << sit++->data() << ")";
    std::cout << std::endl;
  }
  return 0;
}
